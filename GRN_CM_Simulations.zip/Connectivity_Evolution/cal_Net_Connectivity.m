function [c_Pop] = cal_Net_Connectivity(gene_Net,size_Net,gene_N)

for n = size_Net:-1:1
    select_W = gene_Net{n}{2};
    c_Pop(n) = sum(sum(select_W~=0))/gene_N^2;
end


