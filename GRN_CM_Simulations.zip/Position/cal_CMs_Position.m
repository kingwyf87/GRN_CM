function [P_CM_S0,P_CM_S1,P_CM_S2,P_CM_S3,P_CM_S4] = cal_CMs_Position(gene_Net,size_Net,gene_N,iter_T,tau,a,select_N)

counter_S0 = 0;
counter_S1 = 0;
counter_S2 = 0;
counter_S3 = 0;
counter_S4 = 0;

gene_Net_S0 = cell(1,select_N);
gene_Net_S1 = cell(1,select_N);
gene_Net_S2 = cell(1,select_N);
gene_Net_S3 = cell(1,select_N);
gene_Net_S4 = cell(1,select_N);

while (counter_S0<select_N)
    
    n = 0;
    flag = 1;
    
    while (n<size_Net&&flag==1)
         
        n = n+1;
         
        [mut_Net,pos_Mut] = net_Mut(gene_Net{n},gene_N);    
        dev_S = net_Dev(mut_Net{2},mut_Net{1},iter_T,a);
        
        if (is_Equilibrium(dev_S,iter_T,gene_N,tau)==0)          
            mut_Net{2}(pos_Mut(1),pos_Mut(2)) = randn(1,1);          
            counter_S0 = counter_S0+1;            
            gene_Net_S0{counter_S0} = mut_Net;            
            if (counter_S0>=select_N)
                flag =0;
            end            
        end    
            
    end
    
% 	counter_S0
   
end

while (counter_S1<select_N||counter_S2<select_N||counter_S3<select_N||counter_S4<select_N)
    
    n = 0;
    flag = 1;
    
    while (n<size_Net&&flag==1)
        
        n = n+1;        
        
        [mut1_Net,pos_Mut1] = net_Mut(gene_Net{n},gene_N);    
        dev_S = net_Dev(mut1_Net{2},mut1_Net{1},iter_T,a);
        
        if (is_Equilibrium(dev_S,iter_T,gene_N,tau)==0)
        
            [mut2_Net,pos_Mut2] = net_Mut(mut1_Net,gene_N);       
            mut_Dis = net_min_Dis_Calculate(pos_Mut2(1),pos_Mut2(2),pos_Mut1(1),pos_Mut1(2),mut2_Net{2});
           
           if (mut_Dis==1&&counter_S1<select_N)
               counter_S1 = counter_S1+1;
               gene_Net_S1{counter_S1} = mut2_Net;
           elseif (mut_Dis==2&&counter_S2<select_N)
               counter_S2 = counter_S2+1;
               gene_Net_S2{counter_S2} = mut2_Net;
           elseif (mut_Dis==3&&counter_S3<select_N)
               counter_S3 = counter_S3+1;
               gene_Net_S3{counter_S3} = mut2_Net;
            elseif (mut_Dis==4&&counter_S4<select_N)
               counter_S4 = counter_S4+1;
               gene_Net_S4{counter_S4} = mut2_Net;
           end
            
           if(counter_S1>=select_N&&counter_S2>=select_N&&counter_S3>=select_N&&counter_S4>=select_N)
               flag =0;
           end
        
        end
        
    end
    
%     counter_S1
%     counter_S2
%     counter_S3
%     counter_S4
    
end


[P_CM_S0] = cal_P_stable(gene_Net_S0,select_N,iter_T,a,gene_N,tau);

[P_CM_S1] = cal_P_stable(gene_Net_S1,select_N,iter_T,a,gene_N,tau);

[P_CM_S2] = cal_P_stable(gene_Net_S2,select_N,iter_T,a,gene_N,tau);

[P_CM_S3] = cal_P_stable(gene_Net_S3,select_N,iter_T,a,gene_N,tau);

[P_CM_S4] = cal_P_stable(gene_Net_S4,select_N,iter_T,a,gene_N,tau);