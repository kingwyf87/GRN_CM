function [R_CM_All,R_CM_Off,R_CM_On] = cal_CM_Weight_Change2(gene_Net,size_Net,gene_N,iter_T,a,tau,range_W,step_W)

for i = 1:((range_W*2)/step_W+1)
    W(i) = -range_W+(i-1)*step_W;
end

for w = 1:length(W)
    
%     w
    
    AA = 0;
    BB = 0;
    CC = 0;
    
    for n = 1:size_Net
        
        % set inicial network
        mut_R = gene_Net{n}{2};
        
        % generate random mutation position
        mut_Pos = randi(gene_N,[1,2]);
        while (gene_Net{n}{2}(mut_Pos(1),mut_Pos(2))==0)
            mut_Pos = randi(gene_N,[1,2]);
        end
        
        mut_R(mut_Pos(1),mut_Pos(2)) = mut_R(mut_Pos(1),mut_Pos(2))+ W(w); 

        % developmental S with new mutated R
        dev_S = net_Dev(mut_R,gene_Net{n}{1},iter_T,a);

        % viability test 
        if (is_Equilibrium(dev_S,iter_T,gene_N,tau)==1)
            AA = AA +1;
            if (mut_Pos(1)~=mut_Pos(2))
                BB = BB + 1;
            else
                CC = CC + 1;
            end
        end

    end
    
    R_CM_All(w) = AA/10000;
    R_CM_Off(w) = BB/10000;
    R_CM_On(w) = CC/10000;    
    
end

    
    

        
