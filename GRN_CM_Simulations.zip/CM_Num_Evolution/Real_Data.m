function Real_Data()

%%
load Cytosolic_dN_dS_Sl-Sv
y1 = data;
load Cytosolic_dN_dS_Sc-Sn
y2 = data;
%%
boxplot([y1,y2],'notch','on','labels',{'S. latifolia - S. vulgaris','S. conica - S. noctiflora'})
set(gca,'FontName','Arial','FontSize',15)
txt = findobj(gca,'Type','text');
set(txt,'FontName','Arial','FontSize',15)
title({'Comparison of Cytosolic dn/ds'},... 
    'FontSize',20,...
    'FontName','Arial');
ylabel('dn/ds',...
    'FontSize',15,...
    'FontName','Arial');
%%
load Plastid_dN_dS_Sl-Sv
y1 = data;
load Plastid_dN_dS_Sc-Sn
y2 = data;
%%
boxplot([y1,y2],'notch','on','labels',{'S. latifolia - S. vulgaris','S. conica - S. noctiflora'})
set(gca,'FontName','Arial','FontSize',15)
txt = findobj(gca,'Type','text');
set(txt,'FontName','Arial','FontSize',15)
title({'Comparison of Plastid dn/ds'},... 
    'FontSize',20,...
    'FontName','Arial');
ylabel('dn/ds',...
    'FontSize',15,...
    'FontName','Arial');
%%
load Mito_dN_dS_Sl-Sv
y1 = data;
load Mito_dN_dS_Sc-Sn
y2 = data;
%%
boxplot([y1,y2],'notch','on','labels',{'S. latifolia - S. vulgaris','S. conica - S. noctiflora'})
set(gca,'FontName','Arial','FontSize',15)
txt = findobj(gca,'Type','text');
set(txt,'FontName','Arial','FontSize',15)
title({'Comparison of Mitochondrial dn/ds'},... 
    'FontSize',20,...
    'FontName','Arial');
ylabel('dn/ds',...
    'FontSize',15,...
    'FontName','Arial');