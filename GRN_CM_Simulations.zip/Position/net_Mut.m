% gene notwork mutation function
function [mut_Net,mut_Pos] = net_Mut(gene_Net,gene_N)

% set inicial network 
mut_Net{1} = gene_Net{1};
mut_Net{2} = gene_Net{2};

% generate random mutation position
mut_Pos = randi(gene_N,[1,2]);
while (mut_Net{2}(mut_Pos(1),mut_Pos(2))==0)
   mut_Pos = randi(gene_N,[1,2]);
end
      
% network mutated 
mut_Net{2}(mut_Pos(1),mut_Pos(2)) = randn(1,1);
