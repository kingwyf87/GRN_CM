function Figure_Plot()

% % % % % % % % % % % % % % % % 
% %       Plot Results      % %
% % % % % % % % % % % % % % % %
%%
clear
clc
%%
gene_N = 20;
K = 4;
c = K/gene_N;
dis_Pos = [0 1 2 3 4];
T = 100;
size_Net = 10000;
%%
net_Robustness_Dis_DM_CM = [];
net_Init_Robustness_Dis_DM_CM = [];
for n = 1:length(dis_Pos)
   load(['net_Robustness_N',num2str(gene_N),'_Dis_DM_CM_',num2str(dis_Pos(n))])
   net_Robustness_Dis_DM_CM = [net_Robustness_Dis_DM_CM;net_Robustness];
   load(['net_Init_Robustness_N',num2str(gene_N),'_Dis_DM_CM_',num2str(dis_Pos(n))])
   net_Init_Robustness_Dis_DM_CM = [net_Init_Robustness_Dis_DM_CM;net_Robustness];
end
save(['net_Robustness_Dis_DM_CM_N',num2str(gene_N),'_K',num2str(K)],'net_Robustness_Dis_DM_CM')
save(['net_Init_Robustness_Dis_DM_CM_N',num2str(gene_N),'_K',num2str(K)],'net_Init_Robustness_Dis_DM_CM')
errorbar(dis_Pos,mean(net_Robustness_Dis_DM_CM,2),1.96*std(net_Robustness_Dis_DM_CM,0,2)/sqrt(T),'Color',[0 0 1],'LineWidth',1.5,'MarkerSize',20,'Marker','.','LineStyle','none')
hold on;
errorbar(dis_Pos,mean(net_Init_Robustness_Dis_DM_CM,2),1.96*std(net_Init_Robustness_Dis_DM_CM,0,2)/sqrt(T),'Color',[1 0 0],'LineWidth',1.5,'MarkerSize',20,'Marker','.','LineStyle','none')
hold off;
title({'Test for Robustness of Stable Networks with Different DM-CM Distance' ,strcat(' [Pop=',num2str(size_Net),', N=',num2str(gene_N),', c=',num2str(c),']')},...
    'FontSize',30,...
    'FontName','Arial');
xlabel(['Distance Between DM and CM'],...
    'FontSize',25,...
    'FontName','Arial');
ylabel(['Mean Robustness'],...
    'FontSize',25,...
    'FontName','Arial');
text1 = ['N',num2str(gene_N),', c=',num2str(c),'(Initial)'];
text2 = ['N',num2str(gene_N),', c=',num2str(c),'(Compensated)'];
legend1 = legend(text1,text2);
set(legend1,'Location','NorthEast','FontSize',25,'FontName','Arial');
% ylim([0.7,0.8])
set(gca,'XTick',[0:4],'FontName','Arial','FontSize',20)


% % % % % % % % % % % % % % %
% Plot Change in Robustness %
% % % % % % % % % % % % % % %
%%
load net_Robustness_Dis_DM_CM_N5_K2
R_N5_CM = net_Robustness_Dis_DM_CM;
load net_Robustness_Dis_DM_CM_N20_K4
R_N20_CM = net_Robustness_Dis_DM_CM;
load net_Robustness_Dis_DM_CM_N40_K6
R_N40_CM = net_Robustness_Dis_DM_CM;
%%
load net_Neutral_Dis_Robustness_N5_K2
R_N5_Neutral = net_Neutral_Dis_Robustness;
load net_Neutral_Dis_Robustness_N20_K4
R_N20_Neutral = net_Neutral_Dis_Robustness;
load net_Neutral_Dis_Robustness_N40_K6
R_N40_Neutral = net_Neutral_Dis_Robustness;
%%
for n = 1:100
    R_N5_CM_Change(:,n) = (R_N5_CM(:,n)-min(R_N5_CM(:,n)))./min(R_N5_CM(:,n))*100;
end
for n = 1:100
    R_N20_CM_Change(:,n) = (R_N20_CM(:,n)-min(R_N20_CM(:,n)))./min(R_N20_CM(:,n))*100;
end
for n = 1:100
    R_N40_CM_Change(:,n) = (R_N40_CM(:,n)-min(R_N40_CM(:,n)))./min(R_N40_CM(:,n))*100;
end
for n = 1:100
    R_N5_Neutral_Change(:,n) = (R_N5_Neutral(:,n)-min(R_N5_Neutral(:,n)))./min(R_N5_Neutral(:,n))*100;
end
for n = 1:100
    R_N20_Neutral_Change(:,n) = (R_N20_Neutral(:,n)-min(R_N20_Neutral(:,n)))./min(R_N20_Neutral(:,n))*100;
end
for n = 1:100
    R_N40_Neutral_Change(:,n) = (R_N40_Neutral(:,n)-min(R_N40_Neutral(:,n)))./min(R_N40_Neutral(:,n))*100;
end
% R_N5_CM_Change = (R_N5_CM-min(R_N5_CM(:)))./min(R_N5_CM(:))*100;
% R_N20_CM_Change = (R_N20_CM-min(R_N20_CM(:)))./min(R_N20_CM(:))*100;
% R_N40_CM_Change = (R_N40_CM-min(R_N40_CM(:)))./min(R_N40_CM(:))*100;
% R_N5_Neutral_Change = (R_N5_Neutral-min(R_N5_Neutral(:)))./min(R_N5_Neutral(:))*100;
% R_N20_Neutral_Change = (R_N20_Neutral-min(R_N20_Neutral(:)))./min(R_N20_Neutral(:))*100;
% R_N40_Neutral_Change = (R_N40_Neutral-min(R_N40_Neutral(:)))./min(R_N40_Neutral(:))*100;
%%
save R_CM_Change_Dis_N5_K2 R_N5_CM_Change
save R_CM_Change_Dis_N20_K4 R_N20_CM_Change
save R_CM_Change_Dis_N40_K6 R_N40_CM_Change
save R_Neutral_Change_Dis_N5_K2 R_N5_Neutral_Change
save R_Neutral_Change_Dis_N20_K4 R_N20_Neutral_Change
save R_Neutral_Change_Dis_N40_K6 R_N40_Neutral_Change
%%
y1 = R_N5_Neutral_Change;
y2 = R_N5_CM_Change;
gene_N = 5;
K = 2;
%%
y1 = R_N20_Neutral_Change;
y2 = R_N20_CM_Change;
gene_N = 20;
K = 4;
%%
y1 = R_N40_Neutral_Change;
y2 = R_N40_CM_Change;
gene_N = 40;
K = 6;
%%
c = K/gene_N;
dis_Pos = [0 1 2 3 4];
T = 100;
size_Net = 10000;
%%
errorbar(dis_Pos,mean(y1,2),1.96*std(y1,0,2)/sqrt(T),'Color',[0 0 1],'LineWidth',1.5,'MarkerSize',20,'Marker','.','LineStyle','none')
hold on;
errorbar(dis_Pos,mean(y2,2),1.96*std(y2,0,2)/sqrt(T),'Color',[1 0 0],'LineWidth',1.5,'MarkerSize',20,'Marker','.','LineStyle','none')
hold off;
title({'Test for Robustness of Stable Networks with Different Mutation Distance' ,strcat(' [Pop=',num2str(size_Net),', N=',num2str(gene_N),', c=',num2str(c),']')},...
    'FontSize',30,...
    'FontName','Arial');
xlabel(['Shift in Gene Regulation (Fold Change)'],...
    'FontSize',25,...
    'FontName','Arial');
ylabel(['Changed Robustness (%)'],...
    'FontSize',25,...
    'FontName','Arial');
text1 = ['N',num2str(gene_N),', c=',num2str(c),'(Neutral)'];
text2 = ['N',num2str(gene_N),', c=',num2str(c),'(Compensatory)'];
legend1 = legend(text1,text2);
set(legend1,'Location','SouthEast','FontSize',25,'FontName','Arial');
xlim([-0.1,4.1])
set(gca,'XTick',[0:4],'FontName','Arial','FontSize',20)


