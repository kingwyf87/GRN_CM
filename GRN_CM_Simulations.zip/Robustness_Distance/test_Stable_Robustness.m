function test_Stable_Robustness(gene_N,max_T,dis_Pos)

% clear workspace
clc

% Load Data
load(['gene_Satble_Net_N',num2str(gene_N),'_Dis_DM_CM_',num2str(dis_Pos)])

% % set number of genes
% gene_N = 5;
% 
% % set maximum of independent runs
% max_T = 100;

% set gene networksize
size_Net = 10000;

% set activation constant
a = 100;

% set iteration times for stable development
iter_T = 100;

% set time interval
tau = 10;

% % % % % % % % % % % % % % % % % % 
for t = 1:max_T
    
    t

    % 1th Round Mutation 
    [mut_gene_Net] = mut_Net(pos_Net,size_Net,gene_N);

    % Collect Stable Networks After One Round Mutation
    [stable_gene_Net] = stable_NetCollect(mut_gene_Net,size_Net,iter_T,a,gene_N,tau);

    % Robutness after Two Mutational Steps
    [net_Robustness(t)] = length(stable_gene_Net)/size_Net;

end

save(['net_Robustness_N',num2str(gene_N),'_Dis_DM_CM_',num2str(dis_Pos)],'net_Robustness')