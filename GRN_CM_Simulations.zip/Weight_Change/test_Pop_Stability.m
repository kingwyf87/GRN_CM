function [resluts] = test_Pop_Stability(gene_Net,gene_N,size_Net,a)


% set iteration times for stable development
iter_T = 100;

% set time interval
tau = 10;

% test
counter = 0;
for n = 1:size_Net
    
    % developmental S with new mutated R
    dev_S = net_Dev(gene_Net{n}{2},gene_Net{n}{1},iter_T,a);

    % stability test 
    if (is_Equilibrium(dev_S,iter_T,gene_N,tau)==1)
        counter = counter +1;
    end

end

if (counter==size_Net)
    resluts = 1;
else
    resluts = 0;
end

