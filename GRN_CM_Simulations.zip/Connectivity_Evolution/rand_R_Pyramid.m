% R matrix initialize function
function result_R = rand_R_Pyramid(N)

temp_R = zeros(N,N);

if(rand>0.5)
    temp_R(2,1) = randn(1,1);
    edges{1} = [2,1];
else
    temp_R(1,2) = randn(1,1);
    edges{1} = [1,2];
end

if(rand>0.5)
    temp_R(3,1) = randn(1,1);
    edges{2} = [3,1];
else
    temp_R(1,3) = randn(1,1);
    edges{2} = [1,3];
end

if(rand>0.5)
    temp_R(3,2) = randn(1,1);
    edges{3} = [3,2];
else
    temp_R(2,3) = randn(1,1);
    edges{3} = [2,3];
end

if(rand>0.5)
    temp_R(4,2) = randn(1,1);
    edges{4} = [4,2];
else
    temp_R(2,4) = randn(1,1);
    edges{4} = [2,4];
end

if(rand>0.5)
    temp_R(5,2) = randn(1,1);
    edges{5} = [5,2];
else
    temp_R(2,5) = randn(1,1);
    edges{5} = [2,5];
end

if(rand>0.5)
    temp_R(5,3) = randn(1,1);
    edges{6} = [5,3];
else
    temp_R(3,5) = randn(1,1);
    edges{6} = [3,5];
end

if(rand>0.5)
    temp_R(5,4) = randn(1,1);
    edges{7} = [5,4];
else
    temp_R(4,5) = randn(1,1);
    edges{7} = [4,5];
end

if(rand>0.5)
    temp_R(7,4) = randn(1,1);
    edges{8} = [7,4];
else
    temp_R(4,7) = randn(1,1);
    edges{8} = [4,7];
end

if(rand>0.5)
    temp_R(8,4) = randn(1,1);
    edges{9} = [8,4];
else
    temp_R(4,8) = randn(1,1);
    edges{9} = [4,8];
end

if(rand>0.5)
    temp_R(5,8) = randn(1,1);
    edges{10} = [5,8];
else
    temp_R(8,5) = randn(1,1);
    edges{10} = [8,5];
end

if(rand>0.5)
    temp_R(7,8) = randn(1,1);
    edges{11} = [7,8];
else
    temp_R(8,7) = randn(1,1);
    edges{11} = [8,7];
end


if(rand>0.5)
    temp_R(9,8) = randn(1,1);
    edges{12} = [9,8];
else
    temp_R(8,9) = randn(1,1);
    edges{12} = [8,9];
end

if(rand>0.5)
    temp_R(5,9) = randn(1,1);
    edges{13} = [5,9];
else
    temp_R(9,5) = randn(1,1);
    edges{13} = [9,5];
end

if(rand>0.5)
    temp_R(10,9) = randn(1,1);
    edges{14} = [10,9];
else
    temp_R(9,10) = randn(1,1);
    edges{14} = [9,10];
end

if(rand>0.5)
    temp_R(3,6) = randn(1,1);
    edges{15} = [3,6];
else
    temp_R(6,3) = randn(1,1);
    edges{15} = [6,3];
end

if(rand>0.5)
    temp_R(5,6) = randn(1,1);
    edges{16} = [5,6];
else
    temp_R(6,5) = randn(1,1);
    edges{16} = [6,5];
end

if(rand>0.5)
    temp_R(9,6) = randn(1,1);
    edges{17} = [9,6];
else
    temp_R(6,9) = randn(1,1);
    edges{17} = [6,9];
end

if(rand>0.5)
    temp_R(10,6) = randn(1,1);
    edges{18} = [10,6];
else
    temp_R(6,10) = randn(1,1);
    edges{18} = [6,10];
end

self = binornd(1,0.5,1,N);

for n = 1:N
    if(self(n))
        temp_R(n,n) = randn(1,1);
    end
end

% index = randperm(16,30-sum(sum(temp_R~=0)));
% 
% for n = 1:length(index)
%     temp_R(edges{index(n)}(2),edges{index(n)}(1)) = randn(1,1);
% end

result_R = temp_R;