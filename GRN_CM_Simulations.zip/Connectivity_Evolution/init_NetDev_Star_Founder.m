% initial gene network development function
function [init_S,init_R] = init_NetDev_Star_Founder(gene_N,init_S,iter_T,a,tau)

% generate initial R  
init_R = rand_R_Star(gene_N);

% initial gene network development
flag = 1; % set the flag
counter = 1; % set the counter

while(flag==1)
    
    while(counter<=5*2^(2*gene_N) && flag==1)
        
        dev_S = net_Dev(init_R,init_S,iter_T,a);

        if (is_Equilibrium(dev_S,iter_T,gene_N,tau))
            flag = 0;
        else
            % reset the initial R
            init_R = rand_R_Star(gene_N);
        end
        counter = counter + 1;
        
    end
   
end
