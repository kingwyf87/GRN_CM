function [Pos_Distr_CM,Pos_Distr_All] = cal_Mut_Position_Distr(gene_Net,size_Net,gene_N,iter_T,tau,a)

counter_CM = 0;
counter_All = 0;

for n = size_Net:-1:1
        
        % 1st mutation round
        [mut1_Net,pos1_Mut] = net_Mut(gene_Net{n},gene_N);    
        dev_S = net_Dev(mut1_Net{2},mut1_Net{1},iter_T,a);
        
        % collect unteable networks
        if (is_Equilibrium(dev_S,iter_T,gene_N,tau)==0)
            
            % 2nd mutation round
            [mut2_Net,pos2_Mut] = net_Mut(mut1_Net,gene_N);
            
            % calculate distance 
            mut_Dis = net_min_Dis_Calculate(pos2_Mut(1),pos2_Mut(2),pos1_Mut(1),pos1_Mut(2),mut2_Net{2});
            
            if (mut_Dis~=inf)
                
                dev_S = net_Dev(mut2_Net{2},mut2_Net{1},iter_T,a);
                
                if (is_Equilibrium(dev_S,iter_T,gene_N,tau)==1)
                    counter_CM = counter_CM+1;
                    counter_All = counter_All+1;
                    Dis_CM(counter_CM) = mut_Dis;
                    Dis_All(counter_All) = mut_Dis;
                else     
                    counter_All = counter_All+1;
                    Dis_All(counter_All) = mut_Dis;
                end
                
            end
            
        end
                
end

d_Max = max(Dis_All)+1;

for i = 0:d_Max
    
    if (sum(Dis_CM==i)~=0)
        Pos_Distr_CM(i+1) = sum(Dis_CM==i)/length(Dis_CM);
    else
        Pos_Distr_CM(i+1) = 0;
    end
    
    if (sum(Dis_All==i)~=0)
        Pos_Distr_All(i+1) = sum(Dis_All==i)/length(Dis_All);
    else
        Pos_Distr_All(i+1) = 0;
    end

end

    
    

        
