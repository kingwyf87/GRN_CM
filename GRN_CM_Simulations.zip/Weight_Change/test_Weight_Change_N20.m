function test_Weight_Change_N20()

% clear workspace
clc
clear

% load data
load gene_Satble_Net_N20_a100_K_2;
gene_Net = gene_Net_N20;

% set number of genens
gene_N = 20;

% set weight change range
range_W = 5;

% set weight change step size
step_W = 0.05;

% set maximal independent runs
max_T = 500;

% set activation constant
a = 100;

% set iteration times for stable development
iter_T = 100;

% set gene networksize
size_Net = 10000;

% set time interval
tau = 10;

% Test
for n =1:max_T
    
    n
    
    % One Mutation 
    [mut_gene_Net] = net_Mut(gene_Net,size_Net,gene_N);

    % Collect Unstable Networks After One Round Mutation
    [unstable_gene_Net] = unstable_NetCollect(mut_gene_Net,size_Net,iter_T,a,gene_N,tau);

    % Calculate Compensatory Mutation Rate Againt Weight Change
    [P_CM_All_N20(n,:),P_CM_Off_N20(n,:),P_CM_On_N20(n,:)] = cal_CM_Weight_Change(unstable_gene_Net,length(unstable_gene_Net),gene_N,iter_T,a,tau,range_W,step_W,size_Net);

end

save P_CM_All_N20 P_CM_All_N20
save P_CM_Off_N20 P_CM_Off_N20
save P_CM_On_N20 P_CM_On_N20

