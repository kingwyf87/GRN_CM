function [P_CM_All,P_CM_Off,P_CM_On] = cal_CM_Weight_Change(gene_Net,size_Net,gene_N,iter_T,a,tau,range_W,step_W,total_Net)

for i = 1:((range_W*2)/step_W+1)
    W(i) = -range_W+(i-1)*step_W;
end

for w = 1:length(W)
    
%     w
    
    counter_All = 0;
    counter_Off = 0;
    counter_On = 0;
    
    for n = size_Net:-1:1
        
        % set inicial network
        mut_R = gene_Net{n}{2};
        
        % generate random mutation position
        mut_Pos = randi(gene_N,[1,2]);
        while (gene_Net{n}{2}(mut_Pos(1),mut_Pos(2))==0)
            mut_Pos = randi(gene_N,[1,2]);
        end
        
        mut_R(mut_Pos(1),mut_Pos(2)) = mut_R(mut_Pos(1),mut_Pos(2))+ W(w); 

        % developmental S with new mutated R
        dev_S = net_Dev(mut_R,gene_Net{n}{1},iter_T,a);

        % viability test 
        if (is_Equilibrium(dev_S,iter_T,gene_N,tau)==1)
            counter_All = counter_All +1;
            if (mut_Pos(1)~=mut_Pos(2))
                counter_Off = counter_Off + 1;
            else
                counter_On = counter_On + 1;
            end
        end

    end
    
    P_CM_All(w) = counter_All/size_Net;
    P_CM_Off(w) = counter_Off/size_Net;
    P_CM_On(w) = counter_On/size_Net; 
    
% 	  P_CM_All(w) = counter_All/total_Net;
%     P_CM_Off(w) = counter_Off/total_Net;
%     P_CM_On(w) = counter_On/total_Net;   
    
end

    
    

        
