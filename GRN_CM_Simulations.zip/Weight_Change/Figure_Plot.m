function Figure_Plot()

% % % % % % % % % % % % % % % % 
% %       Plot Results      % %
% % % % % % % % % % % % % % % %

load P_CM_All_N20_K4
load P_CM_On_N20_K4
load P_CM_Off_N20_K4

%%
range_W = 5;
step_W = 0.05;
for i = 1:((range_W*2)/step_W+1)
    W(i) = -range_W+(i-1)*step_W;
end
%%
figure
plot(W,mean(P_CM_All_N20,1),'Color',[0 0 1],'LineWidth',1.5);
hold on;
title('Test for Compensatory Mutation Rate Against Weight Change','FontSize',20);
xlabel('Weight Change Caused by Mutation','FontSize',15);
ylabel('Mean Probability of Mutation Being Compensatory (10,000 Initial Sample Networks)','FontSize',15);
legend1 = legend('All Edges: N_{gene} = 5, Network Connectivity = 0.4');
set(legend1,'FontSize',15);

plot(W,mean(P_CM_All_N20,1)+1.96*std(P_CM_All_N20,0,1),'Color',[1 1 0]);
hold on
plot(W,mean(P_CM_All_N20,1)-1.96*std(P_CM_All_N20,0,1),'Color',[1 1 0]);
hold on;
plot(W,mean(P_CM_All_N20,1),'Color',[0 0 1],'LineWidth',1.5);
hold off;
ylim([0 0.065])
xlim([-2.6 2.6])
%% 
set(gcf, 'color', [1 1 1])
export_fig('Figure5a.pdf')
%%
plot(W,mean(P_CM_On_N20,1),'Color',[1 0 0],'LineWidth',1.5);
hold on;
title('Test for Compensatory Mutation Rate Against Weight Change','FontSize',20);
xlabel('Weight Change Caused by Mutation','FontSize',15);
ylabel('Mean Probability of Mutation Being Compensatory (10,000 Initial Sample Networks)','FontSize',15);
legend1 = legend('On Self-Loops: N_{gene} = 5, Network Connectivity = 0.4');
set(legend1,'FontSize',15);
% ylim([-0.001 0.03])
% xlim([-2.6 2.6])
plot(W,mean(P_CM_On_N20,1)+1.96*std(P_CM_On_N20,0,1),'Color',[1 1 0]);
hold on
plot(W,mean(P_CM_On_N20,1)-1.96*std(P_CM_On_N20,0,1),'Color',[1 1 0]);
hold on;
plot(W,mean(P_CM_On_N20,1),'Color',[1 0 0],'LineWidth',1.5);
hold off;
%% 
set(gcf, 'color', [1 1 1])
export_fig('Figure5b.pdf')
%%
plot(W,mean(P_CM_Off_N20,1),'Color',[0.168627455830574 0.505882382392883 0.337254911661148],'LineWidth',1.5);
hold on;
title('Test for Compensatory Mutation Rate Against Weight Change','FontSize',20);
xlabel('Weight Change Caused by Mutation','FontSize',15);
ylabel('Mean Probability of Mutation Being Compensatory (10,000 Initial Sample Networks)','FontSize',15);
legend1 = legend('Off Self-Loops: N_{gene} = 5, Network Connectivity = 0.4');
set(legend1,'FontSize',15);
ylim([0 0.04])
xlim([-2.6 2.6])
plot(W,mean(P_CM_Off_N20,1)+1.96*std(P_CM_Off_N20,0,1),'Color',[1 1 0]);
hold on
plot(W,mean(P_CM_Off_N20,1)-1.96*std(P_CM_Off_N20,0,1),'Color',[1 1 0]);
hold on;
plot(W,mean(P_CM_Off_N20,1),'Color',[0.168627455830574 0.505882382392883 0.337254911661148],'LineWidth',1.5);
hold off;
%% 
set(gcf, 'color', [1 1 1])
export_fig('Figure5c.pdf')
%%
% % % % % % % % % % % % % % % % % 
% % %        ALL Edges        % %
% % % % % % % % % % % % % % % % %
% 
% load P_CM_W_Change_N20_ALL_Edges.mat;
% 
% range_W = 2.5;
% step_W = 0.02;
% for i = 1:((range_W*2)/step_W+1)
%     W(i) = -range_W+(i-1)*step_W;
% end
% figure;
% plot(W,mean(P_CM_W_Change_N20,1),'Color',[1 0 0],'LineWidth',2.5);
% hold on;
% title('Test for Compensatory Mutation Rate Against Weight Change (ALL Edges)');
% xlabel('Weight Change Caused by Mutation');
% ylabel('Probability of Mutation Being Compensatory');
% legend('CMs N = 5 c = 0.4');
% hold off;
% 
% errorbar(W,mean(P_CM_W_Change_N20,1),std(P_CM_W_Change_N20,0,1))
% 
% % % % % % % % % % % % % % % % % 
% % %      Off Self-Loop      % %
% % % % % % % % % % % % % % % % %
% 
% load P_CM_W_Change_N20_Off_Loop.mat;
% 
% range_W = 2.5;
% step_W = 0.02;
% for i = 1:((range_W*2)/step_W+1)
%     W(i) = -range_W+(i-1)*step_W;
% end
% figure;
% plot(W,mean(P_CM_W_Change_N20,1),'Color',[1 0 0],'LineWidth',2.5);
% hold on;
% title('Test for Compensatory Mutation Rate Against Weight Change (Off Self-Loop)');
% xlabel('Weight Change Caused by Mutation');
% ylabel('Probability of Mutation Being Compensatory');
% legend('CMs N = 5 c = 0.4');
% hold off;
% 
% errorbar(W,mean(P_CM_W_Change_N20,1),std(P_CM_W_Change_N20,0,1))
% 
% % % % % % % % % % % % % % % % % 
% % %       On Self-Loop      % %
% % % % % % % % % % % % % % % % %
% 
% load P_CM_W_Change_N20_On_Loop;
% 
% range_W = 2.5;
% step_W = 0.02;
% for i = 1:((range_W*2)/step_W+1)
%     W(i) = -range_W+(i-1)*step_W;
% end
% figure;
% plot(W,mean(P_CM_W_Change_N20,1),'Color',[1 0 0],'LineWidth',2.5);
% hold on;
% title('Test for Compensatory Mutation Rate Against Weight Change (On Loop)');
% xlabel('Weight Change Caused by Mutation');
% ylabel('Probability of Mutation Being Compensatory');
% legend('CMs N = 5 c = 0.4');
% hold off;
% 
% errorbar(W,mean(P_CM_W_Change_N20,1),std(P_CM_W_Change_N20,0,1))


%%
num_Bins = 100;
%%
figure;
subplot(2,1,1)
hist(w_All,num_Bins)
title('Distribution of Regulatory Effect Sizes of Stable Networks in All Regulatory Edges','FontSize',20);
ylabel('Number of Individuals','FontName','Arial','FontSize',15);
xlabel('Regulatory Effect Sizes','FontName','Arial','FontSize',15);
set(gca,'FontName','Arial','FontSize',20)
xlim([-5 5])
subplot(2,1,2)
hist(w_Self,num_Bins)
title('Distribution of Regulatory Effect Sizes of Stable Networks in Self-Regulatory Edges','FontSize',20);
ylabel('Number of Individuals','FontName','Arial','FontSize',15);
xlabel('Regulatory Effect Sizes','FontName','Arial','FontSize',15);
set(gca,'FontName','Arial','FontSize',20)
xlim([-5 5])
%%
figure;
subplot(2,1,1)
hist(w_DM_All,num_Bins)
title('Distribution of Regulatory Effect Sizes of Deleterious Mutations in All Regulatory Edges','FontSize',20);
ylabel('Number of Deleterious Mutations','FontName','Arial','FontSize',15);
xlabel('Regulatory Effect Sizes','FontName','Arial','FontSize',15);
set(gca,'FontName','Arial','FontSize',20)
xlim([-5 5])
subplot(2,1,2)
hist(w_DM_Self,num_Bins)
title('Distribution of Regulatory Effect Sizes of Deleterious Mutations in Self-Regulatory Edges','FontSize',20);
ylabel('Number of Deleterious Mutations','FontName','Arial','FontSize',15);
xlabel('Regulatory Effect Sizes','FontName','Arial','FontSize',15);
set(gca,'FontName','Arial','FontSize',20)
xlim([-5 5])
%%
figure;
subplot(2,1,1)
hist(w_CM_All,num_Bins)
title('Distribution of Regulatory Effect Sizes of Compensatory Mutations in All Regulatory Edges','FontSize',20);
ylabel('Number of Compensatory Mutations','FontName','Arial','FontSize',15);
xlabel('Regulatory Effect Sizes','FontName','Arial','FontSize',15);
set(gca,'FontName','Arial','FontSize',20)
xlim([-5 5])
subplot(2,1,2)
hist(w_CM_Self,num_Bins)
title('Distribution of Regulatory Effect Sizes of Compensatory Mutations in Self-Regulatory Edges','FontSize',20);
ylabel('Number of Compensatory Mutations','FontName','Arial','FontSize',15);
xlabel('Regulatory Effect Sizes','FontName','Arial','FontSize',15);
set(gca,'FontName','Arial','FontSize',20)
xlim([-5 5])


%% Init
gene_N = 20;
c = 0.2;
max_T = 100;
edges = [-4.75:0.5:4.75];
%%
temp_Str = num2str(c);
counter = 0;
for n = 1:length(temp_Str)
    if (temp_Str(n)~='.')
        counter = counter+1;
        stP_c(counter) = temp_Str(n);
    end
end
%%
load(['w_All_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)]);
%%
for n = 1:max_T
    h = histogram(w_All{n},edges,'Normalization','probability');
    prob_W_All(n,:) = h.Values; 
end
%%
save(['prob_W_All_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)],'prob_W_All')
%%
load(['w_Self_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)]);
%%
for n = 1:max_T
    h = histogram(w_Self{n},edges,'Normalization','probability');
    prob_W_Self(n,:) = h.Values; 
end
%%
save(['prob_W_Self_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)],'prob_W_Self')
%%
load(['w_Non_Self_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)]);
%%
for n = 1:max_T
    h = histogram(w_Non_Self{n},edges,'Normalization','probability');
    prob_W_Non_Self(n,:) = h.Values; 
end
%%
save(['prob_W_Non_Self_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)],'prob_W_Non_Self')

%% DM
gene_N = 20;
c = 0.2;
max_T = 100;
edges = [-4.75:0.5:4.75];
%%
temp_Str = num2str(c);
counter = 0;
for n = 1:length(temp_Str)
    if (temp_Str(n)~='.')
        counter = counter+1;
        stP_c(counter) = temp_Str(n);
    end
end
%%
load(['w_DM_All_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)]);
%%
for n = 1:max_T
    h = histogram(w_DM_All{n},edges,'Normalization','probability');
    prob_W_DM_All(n,:) = h.Values; 
end
%%
save(['prob_W_DM_All_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)],'prob_W_DM_All')
%%
load(['w_DM_Self_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)]);
%%
for n = 1:max_T
    h = histogram(w_DM_Self{n},edges,'Normalization','probability');
    prob_W_DM_Self(n,:) = h.Values; 
end
%%
save(['prob_W_DM_Self_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)],'prob_W_DM_Self')
%%
load(['w_DM_Non_Self_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)]);
%%
for n = 1:max_T
    h = histogram(w_DM_Non_Self{n},edges,'Normalization','probability');
    prob_W_DM_Non_Self(n,:) = h.Values; 
end
%%
save(['prob_W_DM_Non_Self_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)],'prob_W_DM_Non_Self')

%% CM
gene_N = 20;
c = 0.2;
max_T = 100;
edges = [-4.75:0.5:4.75];
%%
temp_Str = num2str(c);
counter = 0;
for n = 1:length(temp_Str)
    if (temp_Str(n)~='.')
        counter = counter+1;
        stP_c(counter) = temp_Str(n);
    end
end
%%
load(['w_CM_All_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)]);
%%
for n = 1:max_T
    h = histogram(w_CM_All{n},edges,'Normalization','probability');
    prob_W_CM_All(n,:) = h.Values; 
end
%%
save(['prob_W_CM_All_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)],'prob_W_CM_All')
%%
load(['w_CM_Self_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)]);
%%
for n = 1:max_T
    h = histogram(w_CM_Self{n},edges,'Normalization','probability');
    prob_W_CM_Self(n,:) = h.Values; 
end
%%
save(['prob_W_CM_Self_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)],'prob_W_CM_Self')
%%
load(['w_CM_Non_Self_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)]);
%%
for n = 1:max_T
    h = histogram(w_CM_Non_Self{n},edges,'Normalization','probability');
    prob_W_CM_Non_Self(n,:) = h.Values; 
end
%%
save(['prob_W_CM_Non_Self_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)],'prob_W_CM_Non_Self')


%% All
clear
clc
%%
edges = [-4.5:0.5:4.5];
gene_N = 20;
c = 0.2;
max_T = 100;
temp_Str = num2str(c);
counter = 0;
for n = 1:length(temp_Str)
    if (temp_Str(n)~='.')
        counter = counter+1;
        stP_c(counter) = temp_Str(n);
    end
end
%%
figure;
%% Init
load(['prob_W_All_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)]);
subplot(3,1,1)
bar(edges,mean(prob_W_All),'FaceColor',[0.800000011920929 0.800000011920929 0.800000011920929],'BarWidth',1)
hold on;
errorbar(edges,mean(prob_W_All),1.96*std(prob_W_All)/sqrt(5),'LineStyle','none','LineWidth',1.5,'Color',[0 0 0]);
title('Distribution of Regulatory Effect Sizes of Stable Networks in All Regulatory Edges','FontSize',20);
ylabel('Frequency','FontName','Arial','FontSize',15);
xlabel('Regulatory Effect Sizes','FontName','Arial','FontSize',15);
set(gca,'xtick',edges,'FontName','Arial','FontSize',20)
xlim([-5 5])
ylim([0 0.3])
%% DM
subplot(3,1,2)
load(['prob_W_DM_All_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)]);
bar(edges,mean(prob_W_DM_All),'FaceColor',[0.800000011920929 0.800000011920929 0.800000011920929],'BarWidth',1)
hold on;
errorbar(edges,mean(prob_W_DM_All),1.96*std(prob_W_DM_All)/sqrt(5),'LineStyle','none','LineWidth',1.5,'Color',[0 0 0]);
title('Distribution of Regulatory Effect Sizes of Deleterious Mutations in All Regulatory Edges','FontSize',20);
ylabel('Frequency','FontName','Arial','FontSize',15);
xlabel('Regulatory Effect Sizes','FontName','Arial','FontSize',15);
set(gca,'xtick',edges,'FontName','Arial','FontSize',20)
xlim([-5 5])
ylim([0 0.3])
%% CM
subplot(3,1,3)
load(['prob_W_CM_All_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)]);
bar(edges,mean(prob_W_CM_All),'FaceColor',[0.800000011920929 0.800000011920929 0.800000011920929],'BarWidth',1)
hold on;
errorbar(edges,mean(prob_W_CM_All),1.96*std(prob_W_CM_All)/sqrt(5),'LineStyle','none','LineWidth',1.5,'Color',[0 0 0]);
title('Distribution of Regulatory Effect Sizes of Compensatory Mutations in All Regulatory Edges','FontSize',20);
ylabel('Frequency','FontName','Arial','FontSize',15);
xlabel('Regulatory Effect Sizes','FontName','Arial','FontSize',15);
set(gca,'xtick',edges,'FontName','Arial','FontSize',20)
xlim([-5 5])
ylim([0 0.3])


%% Self
clear
clc
%%
edges = [-4.5:0.5:4.5];
gene_N = 20;
c = 0.2;
max_T = 100;
temp_Str = num2str(c);
counter = 0;
for n = 1:length(temp_Str)
    if (temp_Str(n)~='.')
        counter = counter+1;
        stP_c(counter) = temp_Str(n);
    end
end
%%
figure;
%% Init
load(['prob_W_Self_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)]);
subplot(3,1,1)
bar(edges,mean(prob_W_Self),'FaceColor',[0.800000011920929 0.800000011920929 0.800000011920929],'BarWidth',1)
hold on;
errorbar(edges,mean(prob_W_Self),1.96*std(prob_W_Self)/sqrt(5),'LineStyle','none','LineWidth',1.5,'Color',[0 0 0]);
title('Distribution of Regulatory Effect Sizes of Stable Networks in Self Regulatory Edges','FontSize',20);
ylabel('Frequency','FontName','Arial','FontSize',15);
xlabel('Regulatory Effect Sizes','FontName','Arial','FontSize',15);
set(gca,'xtick',edges,'FontName','Arial','FontSize',20)
xlim([-5 5])
ylim([0 0.3])
%% DM
subplot(3,1,2)
load(['prob_W_DM_Self_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)]);
bar(edges,mean(prob_W_DM_Self),'FaceColor',[0.800000011920929 0.800000011920929 0.800000011920929],'BarWidth',1)
hold on;
errorbar(edges,mean(prob_W_DM_Self),1.96*std(prob_W_DM_Self)/sqrt(5),'LineStyle','none','LineWidth',1.5,'Color',[0 0 0]);
title('Distribution of Regulatory Effect Sizes of Deleterious Mutations in Self Regulatory Edges','FontSize',20);
ylabel('Frequency','FontName','Arial','FontSize',15);
xlabel('Regulatory Effect Sizes','FontName','Arial','FontSize',15);
set(gca,'xtick',edges,'FontName','Arial','FontSize',20)
xlim([-5 5])
ylim([0 0.3])
%% CM
subplot(3,1,3)
load(['prob_W_CM_Self_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)]);
bar(edges,mean(prob_W_CM_Self),'FaceColor',[0.800000011920929 0.800000011920929 0.800000011920929],'BarWidth',1)
hold on;
errorbar(edges,mean(prob_W_CM_Self),1.96*std(prob_W_CM_Self)/sqrt(5),'LineStyle','none','LineWidth',1.5,'Color',[0 0 0]);
title('Distribution of Regulatory Effect Sizes of Compensatory Mutations in Self Regulatory Edges','FontSize',20);
ylabel('Frequency','FontName','Arial','FontSize',15);
xlabel('Regulatory Effect Sizes','FontName','Arial','FontSize',15);
set(gca,'xtick',edges,'FontName','Arial','FontSize',20)
xlim([-5 5])
ylim([0 0.3])


%% Non-Self
clear
clc
%%
edges = [-4.5:0.5:4.5];
gene_N = 20;
c = 0.2;
max_T = 100;
temp_Str = num2str(c);
counter = 0;
for n = 1:length(temp_Str)
    if (temp_Str(n)~='.')
        counter = counter+1;
        stP_c(counter) = temp_Str(n);
    end
end
%%
figure;
%% Init
load(['prob_W_Non_Self_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)]);
subplot(3,1,1)
bar(edges,mean(prob_W_Non_Self),'FaceColor',[0.800000011920929 0.800000011920929 0.800000011920929],'BarWidth',1)
hold on;
errorbar(edges,mean(prob_W_Non_Self),1.96*std(prob_W_Non_Self)/sqrt(5),'LineStyle','none','LineWidth',1.5,'Color',[0 0 0]);
title('Distribution of Regulatory Effect Sizes of Stable Networks in Non-Self Regulatory Edges','FontSize',20);
ylabel('Frequency','FontName','Arial','FontSize',15);
xlabel('Regulatory Effect Sizes','FontName','Arial','FontSize',15);
set(gca,'xtick',edges,'FontName','Arial','FontSize',20)
xlim([-5 5])
ylim([0 0.3])
%% DM
subplot(3,1,2)
load(['prob_W_DM_Non_Self_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)]);
bar(edges,mean(prob_W_DM_Non_Self),'FaceColor',[0.800000011920929 0.800000011920929 0.800000011920929],'BarWidth',1)
hold on;
errorbar(edges,mean(prob_W_DM_Non_Self),1.96*std(prob_W_DM_Non_Self)/sqrt(5),'LineStyle','none','LineWidth',1.5,'Color',[0 0 0]);
title('Distribution of Regulatory Effect Sizes of Deleterious Mutations in Non-Self Regulatory Edges','FontSize',20);
ylabel('Frequency','FontName','Arial','FontSize',15);
xlabel('Regulatory Effect Sizes','FontName','Arial','FontSize',15);
set(gca,'xtick',edges,'FontName','Arial','FontSize',20)
xlim([-5 5])
ylim([0 0.3])
%% CM
subplot(3,1,3)
load(['prob_W_CM_Non_Self_N' num2str(gene_N) '_c' stP_c '_max_T' num2str(max_T)]);
bar(edges,mean(prob_W_CM_Non_Self),'FaceColor',[0.800000011920929 0.800000011920929 0.800000011920929],'BarWidth',1)
hold on;
errorbar(edges,mean(prob_W_CM_Non_Self),1.96*std(prob_W_CM_Non_Self)/sqrt(5),'LineStyle','none','LineWidth',1.5,'Color',[0 0 0]);
title('Distribution of Regulatory Effect Sizes of Compensatory Mutations in Non-Self Regulatory Edges','FontSize',20);
ylabel('Frequency','FontName','Arial','FontSize',15);
xlabel('Regulatory Effect Sizes','FontName','Arial','FontSize',15);
set(gca,'xtick',edges,'FontName','Arial','FontSize',20)
xlim([-5 5])
ylim([0 0.3])