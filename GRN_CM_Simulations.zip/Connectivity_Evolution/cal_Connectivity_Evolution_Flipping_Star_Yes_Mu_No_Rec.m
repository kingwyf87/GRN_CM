function [c_Pop_All,c_Pop] = cal_Connectivity_Evolution_Flipping_Star_Yes_Mu_No_Rec(gene_Net,size_Net,gene_N,max_G,a,iter_T,tau)

%% evolution (with mutation and no recombination)
counter_C = 0;
for g = 1:max_G
    
    g

    % popluation reproduction
    counter_Pop = 0;
    new_Pop = cell(1,size_Net);
    while (counter_Pop<size_Net)

        % gernerate one random position
        pos_Rand = randi([1,size_Net],1,1);

        % target genotypes recombination
        [init_S] = gene_Net{pos_Rand}{1};
        [select_W] = gene_Net{pos_Rand}{2};
        
        % one mutation      
        [mut_W] = k_Mut_One(select_W,gene_N); 

        % test EQ for W
        dev_S = net_Dev(mut_W,init_S,iter_T,a);
        if (is_Equilibrium(dev_S,iter_T,gene_N,tau))               
            stable_Flag = 1;
        else
            stable_Flag = 0;
        end

        % selection for W
        if (stable_Flag==1)
            counter_Pop = counter_Pop+1;
            [new_Pop{counter_Pop}{2}] = mut_W;
            [new_Pop{counter_Pop}{1}] = init_S;
        end

    end

    gene_Net = new_Pop;

	% record network connectivity every 50 generations
    if (mod(g-1,50)==0&&g~=1)
        counter_C = counter_C+1;
        [c_Pop_All(counter_C)] = mean(cal_Net_Connectivity(gene_Net,size_Net,gene_N));
    end
    
end

c_Pop = gene_Net;