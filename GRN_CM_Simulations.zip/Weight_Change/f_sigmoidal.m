% sigmoidal calculate function   
function result_f = f_sigmoidal(x,a)
result_f = 2./(1+exp(-a.*x))-1;
