% gene network development function
function dev_S = net_Dev(mat_R,mat_S,iter_T,a)

% 1
% for t = 1:iter_T
%     for i = 1:gene_N
%         temp_Sum = 0;
%         for j = 1:gene_N
%             temp_Sum = temp_Sum + mat_R(i,j)*mat_S(t,j);
%         end
%         mat_S(t+1,i) = f_sigmoidal(temp_Sum,a);
%     end
% end

% 2
for t = 1:iter_T
    
	mat_S(t+1,:) = f_sigmoidal(mat_S(t,:)*mat_R,a);
    
end
dev_S = mat_S;