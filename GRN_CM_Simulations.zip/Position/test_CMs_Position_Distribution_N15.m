function test_CMs_Position_Distribution_N15()

% clear workspace
clc
clear

% load data
load gene_Satble_Net_N15_a100_K4;

% set gene numbers
gene_N = 15;

% set maximal independent runs
max_T = 100;

% set activation constant
a = 100;

% set iteration times for stable development
iter_T = 100;

% set time interval
tau = 10;

% set gene network size
size_Init = 10000;

% resample the network
size_Net = 10*size_Init;
gene_Net_N15_R = net_Increase(gene_Net_N15,size_Net);

% Test
for n = 1:max_T
    
    n
    [Pos_Distr_CM_N15{n},Pos_Distr_All_N15{n}] = cal_Mut_Position_Distr(gene_Net_N15_R,size_Net,gene_N,iter_T,tau,a);
    
end

save Pos_Distr_CM_N15_K4 Pos_Distr_CM_N15
save Pos_Distr_All_N15_K4 Pos_Distr_All_N15

d_Max = 7;

for n = 1:max_T
    
    len_CM = length(Pos_Distr_CM_N15{n});
    Distr_CM_N15(n,1:len_CM) = Pos_Distr_CM_N15{n};
    if len_CM<d_Max
        Distr_CM_N15(n,len_CM+1:d_Max) = 0;
    end
    
    len_All = length(Pos_Distr_All_N15{n});
    Distr_All_N15(n,1:len_All) = Pos_Distr_All_N15{n};
    if len_All<d_Max
        Distr_All_N15(n,len_All+1:d_Max) = 0;
    end    
   
end

save Distr_CM_N15_K4 Distr_CM_N15
save Distr_All_N15_K4 Distr_All_N15


figure;
plot(0:d_Max-1,mean(Distr_CM_N15),'Color',[0 0 1],'LineWidth',1.5);
hold on;
plot(0:d_Max-1,mean(Distr_All_N15),'Color',[1 0 0],'LineWidth',1.5);
hold on;
title('Test for Compensatory Mutation Positions (N = 5, c = 0.4)');
ylabel('Percentage');
xlabel('Distance from Deleterious Mutation');
legend('Compensatory Mutations','ALL Mutations');
hold off;

