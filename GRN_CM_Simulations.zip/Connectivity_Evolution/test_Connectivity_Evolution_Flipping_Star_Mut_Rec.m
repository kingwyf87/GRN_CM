function test_Connectivity_Evolution_Flipping_Star_Mut_Rec(gene_N,c,max_G,max_T,flag_Mu,flag_Rec)

%% clear work space
clc

%% load data
load(['gene_Satble_Net_N',num2str(gene_N),'_a100_Y_Star_Founder_c',c_num2str(c)])

%% set parameters
% % set maximum of independent runs
% max_T = 100;
% 
% % set maximum gernation
% max_G = 5000;
% 
% % set flipping gernation for relaxed selction
% cycle_G = 50;
%  
% % set network connectivity
% c = 0.8;
% 
% % set gene number
% gene_N = 5;

% set gene networksize
size_Net = 10000;

% set activation constant
a = 100;

% set iteration times for stable development
iter_T = 100;

% set time interval
tau = 10;

%% Testing
for t = 1:max_T
   
    t
    
    if(flag_Mu==0&&flag_Rec==0)
        [c_Pop_All(:,t),c_gene_Net{t}] = cal_Connectivity_Evolution_Flipping_Star_No_Mu_No_Rec(gene_Net,size_Net,gene_N,max_G+1);
    elseif(flag_Mu==1&&flag_Rec==0)
        [c_Pop_All(:,t),c_gene_Net{t}] = cal_Connectivity_Evolution_Flipping_Star_Yes_Mu_No_Rec(gene_Net,size_Net,gene_N,max_G+1,a,iter_T,tau);
    elseif(flag_Mu==0&&flag_Rec==1)
        [c_Pop_All(:,t),c_gene_Net{t}] = cal_Connectivity_Evolution_Flipping_Star_No_Mu_Yes_Rec(gene_Net,size_Net,gene_N,max_G+1,a,iter_T,tau);
    end 
    
    %% save results
    save_Name = ['c_Pop_All_Flipping_Star_Founder_Mu',num2str(flag_Mu),'_Rec',num2str(flag_Rec),'_N',num2str(gene_N),'_c',c_num2str(c)];
    save (save_Name,'c_Pop_All')
	save_Name = ['pop_All_Flipping_Star_Founder_Mu',num2str(flag_Mu),'_Rec',num2str(flag_Rec),'_N',num2str(gene_N),'_c',c_num2str(c)];
    save (save_Name,'c_gene_Net') 
    
end

