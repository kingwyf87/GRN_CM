function test_DM_CM_Position_Distribution(gene_N,c,a,max_T,d_Max)

% clear workspace
clc

% load data
load(['gene_Satble_Net_N',num2str(gene_N),'_a',num2str(a),'_K',num2str(c*gene_N)])

% % set gene numbers
% gene_N = 40;
% 
% % set activation constant
% a = 100;
% 
% % set maximal independent runs
% max_T = 100;

% set iteration times for stable development
iter_T = 100;

% set time interval
tau = 10;

% set gene network size
size_Init = 10000;

% resample the network
size_Net = 10*size_Init;
gene_Net_R = net_Increase(gene_Net,size_Net);

% Test
for n = 1:max_T
    
    n
    
    [Pos_Distr_CM{n},Pos_Distr_All{n}] = cal_Mut_Position_Distr(gene_Net_R,size_Net,gene_N,iter_T,tau,a);
    
    save(['Pos_Distr_CM_N',num2str(gene_N),'_K',num2str(c*gene_N)],'Pos_Distr_CM')
    save(['Pos_Distr_All_N',num2str(gene_N),'_K',num2str(c*gene_N)],'Pos_Distr_All')

end

% Gruop Results
for n = 1:max_T
    % CM
    len_CM = length(Pos_Distr_CM{n});
    Distr_CM(n,1:len_CM) = Pos_Distr_CM{n};
    if (len_CM<d_Max)
        Distr_CM(n,len_CM+1:d_Max) = 0;
    end
    % All
    len_All = length(Pos_Distr_All{n});
    Distr_All(n,1:len_All) = Pos_Distr_All{n};
    if (len_All<d_Max)
        Distr_All(n,len_All+1:d_Max) = 0;
    end      
end

save(['Distr_CM_N',num2str(gene_N),'_K',num2str(c*gene_N)],'Distr_CM')
save(['Distr_All_N',num2str(gene_N),'_K',num2str(c*gene_N)],'Distr_All')