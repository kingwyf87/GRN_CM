% test gene notwork stable probobility function
function [P_stable] = cal_P_stable(gene_Net,size_Net,iter_T,a,gene_N,tau,T)

% set initial counter
counter = 0;

% gene notwork mutation
for n = size_Net:-1:1
    
    % developmental S with new mutated R
    dev_S = net_Dev(gene_Net{n}{2},gene_Net{n}{1},iter_T,a);
        
    % viability test 
    if (is_Equilibrium(dev_S,iter_T,gene_N,tau)==1)
        counter = counter+1;        
    end
    
end

P_stable = counter/size_Net;