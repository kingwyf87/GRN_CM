function collect_N_Pos_DM_CM(gene_N,c,a,dis_Pos,num_Sample)

load(['gene_Satble_Net_N',num2str(gene_N),'_a',num2str(a),'_K',num2str(c*gene_N)])

% set gene networksize
size_Net = 10000;

% set iteration times for stable development
iter_T = 100;

% set time interval
tau = 10;

pos_Net = cell(1,num_Sample);
counter = 0;

while(counter<num_Sample)
        
	% gernerate one random position
    pos_Rand = randi([1,size_Net],1,1);
    
    % 1st round of muation
	[mut1_Net,pos_Mut1] = net_Mut(gene_Net{pos_Rand},gene_N);   
    
    % test stability
    dev_S = net_Dev(mut1_Net{2},mut1_Net{1},iter_T,a);
    if (is_Equilibrium(dev_S,iter_T,gene_N,tau)==0)
        % 2nd round of mutation 
        [mut2_Net,pos_Mut2] = net_Mut(mut1_Net,gene_N);
        % calcuale D(DM,CM)
        mut_Dis = net_min_Dis_Calculate(pos_Mut2(1),pos_Mut2(2),pos_Mut1(1),pos_Mut1(2),mut2_Net{2});
        if (mut_Dis==dis_Pos)
            % test stability
            dev_S = net_Dev(mut2_Net{2},mut2_Net{1},iter_T,a); 
            if (is_Equilibrium(dev_S,iter_T,gene_N,tau)==1)     
               counter = counter+1
               pos_Net{counter} = mut2_Net;
               init_Net{counter} = gene_Net{pos_Rand};
            end
        end 
    end 
    
end

% save resutls
save(['gene_Satble_Net_N',num2str(gene_N),'_Dis_DM_CM_',num2str(dis_Pos)],'pos_Net')

save(['gene_Init_Net_N',num2str(gene_N),'_Dis_DM_CM_',num2str(dis_Pos)],'init_Net')


