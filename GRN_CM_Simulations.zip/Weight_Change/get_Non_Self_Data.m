%%
clear
clc
%%
gene_N = 20;
c = 0.2;
max_T = 100;
edges = [-4.75:0.5:4.75];
%%
temp_Str = num2str(c);
counter = 0;
for n = 1:length(temp_Str)
    if (temp_Str(n)~='.')
        counter = counter+1;
        str_c(counter) = temp_Str(n);
    end
end
%% Init
load(['w_All_N' num2str(gene_N) '_c' str_c '_max_T' num2str(max_T)]);
load(['w_Self_N' num2str(gene_N) '_c' str_c '_max_T' num2str(max_T)]);
for n = 1:100
    w_Non_Self{n} = setxor(w_All{n},w_Self{n});
end
save(['w_Non_Self_N' num2str(gene_N) '_c' str_c '_max_T' num2str(max_T)],'w_Non_Self');
%% DM
load(['w_DM_All_N' num2str(gene_N) '_c' str_c '_max_T' num2str(max_T)]);
load(['w_DM_Self_N' num2str(gene_N) '_c' str_c '_max_T' num2str(max_T)]);
for n = 1:100
    w_DM_Non_Self{n} = setxor(w_DM_All{n},w_DM_Self{n});
end
save(['w_DM_Non_Self_N' num2str(gene_N) '_c' str_c '_max_T' num2str(max_T)],'w_DM_Non_Self');
%% CM
load(['w_CM_All_N' num2str(gene_N) '_c' str_c '_max_T' num2str(max_T)]);
load(['w_CM_Self_N' num2str(gene_N) '_c' str_c '_max_T' num2str(max_T)]);
for n = 1:100
    w_CM_Non_Self{n} = setxor(w_CM_All{n},w_CM_Self{n});
end
save(['w_CM_Non_Self_N' num2str(gene_N) '_c' str_c '_max_T' num2str(max_T)],'w_CM_Non_Self');


