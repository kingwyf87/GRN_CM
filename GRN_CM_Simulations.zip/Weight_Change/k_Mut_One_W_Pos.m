% matrix R with one mutation function
function [result_R,result_W,result_Pos] = k_Mut_One_W_Pos(mat_R,gene_N)

% generate random mutation position
mut_Pos = randi(gene_N,[1,2]);
while (mat_R(mut_Pos(1),mut_Pos(2))==0)
    mut_Pos = randi(gene_N,[1,2]);
end
      
% network mutated
result_W = randn(1,1);  
mat_R(mut_Pos(1),mut_Pos(2)) = result_W;
result_R = mat_R;  
result_Pos = mut_Pos;