% R matrix initialize function
function result_R = rand_R_Star(N)

% number of non-zero items
N_non_zero = N-1;

temp_R = zeros(N,N);

% % 1
% direction = binornd(1,0.5,1,N-1);
% all_Gen = 1:N;
% selected_Gen = randi(N);
% Edges = setxor(all_Gen,selected_Gen);
% 
% for n = 1:N_non_zero
%     if(direction(n)==1)
%         temp_R(Edges(n),selected_Gen) = randn(1,1);
%     else
%         temp_R(selected_Gen,Edges(n)) = randn(1,1);
%     end
%     
% end
% 
% result_R = temp_R;


% % 2
% direction = binornd(1,0.5,1,N-1);
% all_Gen = 1:N;
% selected_Gen = randi(N);
% Edges = setxor(all_Gen,selected_Gen);
% 
% for n = 1:N_non_zero
%     if(direction(n)==1)
%         temp_R(Edges(n),selected_Gen) = randn(1,1);
%         if(rand>0.5)
%             temp_R(selected_Gen,Edges(n)) = randn(1,1);
%         end
%     else
%         temp_R(selected_Gen,Edges(n)) = randn(1,1);
%         if(rand>0.5)
%             temp_R(Edges(n),selected_Gen) = randn(1,1);
%         end
%     end    
% end


% 3
direction = binornd(1,0.5,1,N-1);
all_Gen = 1:N;
selected_Gen = randi(N);
Edges = setxor(all_Gen,selected_Gen);

for n = 1:N_non_zero
    if(direction(n)==1)
        temp_R(Edges(n),selected_Gen) = randn(1,1);
        if(rand>0.5)
            temp_R(selected_Gen,Edges(n)) = randn(1,1);
        end
    else
        temp_R(selected_Gen,Edges(n)) = randn(1,1);
        if(rand>0.5)
            temp_R(Edges(n),selected_Gen) = randn(1,1);
        end
    end 
    if (rand<0.5)
        temp_R(Edges(n),Edges(n))= randn(1,1);
    end
end


result_R = temp_R;