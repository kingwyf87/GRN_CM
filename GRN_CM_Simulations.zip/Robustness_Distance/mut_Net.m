% gene notwork mutation function (one mutation)
function  mat_mut_Net = mut_Net(gene_Net,size_Net,gene_N)

% gene notwork mutation
for n = size_Net:-1:1
    
    % inicial S
    mat_mut_Net{n}{1} = gene_Net{n}{1};  
 
    % find the target genotype 
    select_R = gene_Net{n}{2};
  
    % new mutated R
    mat_mut_Net{n}{2} = k_Mut_One(select_R,gene_N);
         
end