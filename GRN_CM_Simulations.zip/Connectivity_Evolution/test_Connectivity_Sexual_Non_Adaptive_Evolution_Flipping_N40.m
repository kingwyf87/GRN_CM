function test_Connectivity_Sexual_Non_Adaptive_Evolution_Flipping_N40(max_G,cycle_G,max_T)

%% clear work space
clc

%% load data
load gene_Satble_Net_N40_a100_Y_Founder_c015

%% set parameters

% % set maximum of independent runs
% max_T = 100;
% 
% % set maximum gernation
% max_G = 5000;
% 
% % set flipping gernation for relaxed selction
% cycle_G = 50;
 
% set gene networksize
size_Net = 10000;

% set gene number
gene_N = 40;

% set network connectivity
c = 0.15;

% set activation constant
a = 100;

% set iteration times for stable development
iter_T = 100;

% set time interval
tau = 10;

% set init Pop
gene_Net = gene_Net_N40;

%% Testing
for t = 1:max_T
   
    t
    
    [c_Pop_All(:,t),c_gene_Net{t}] = cal_Connectivity_Sexual_Non_Adaptive_Evolution_Flipping(gene_Net,size_Net,gene_N,max_G+1,cycle_G,a,iter_T,tau);
    
	%% save results
    save_Name = ['c_Pop_All_Flipping_Founder','_N',num2str(gene_N),'_c',c_num2str(c),'_numCycle',num2str(cycle_G)];
    save (save_Name,'c_Pop_All')
	save_Name = ['pop_All_Flipping_Founder','_N',num2str(gene_N),'_c',c_num2str(c),'_numCycle',num2str(cycle_G)];
    save (save_Name,'c_gene_Net') 
     
end