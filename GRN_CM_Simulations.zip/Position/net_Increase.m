function  [new_gene_Net] = net_Increase(gene_Net,size_Net)

counter = 0;
size_gene_Net = length(gene_Net);

while(counter~=size_Net) 
   counter = counter+1;
   if (counter<=size_gene_Net)
       new_gene_Net{counter}{1} = gene_Net{counter}{1};
       new_gene_Net{counter}{2} = gene_Net{counter}{2};  
   else
       pos_Rand = randi(length(gene_Net),1,1);
       new_gene_Net{counter}{1} = gene_Net{pos_Rand}{1};
       new_gene_Net{counter}{2} = gene_Net{pos_Rand}{2};
   end
end 