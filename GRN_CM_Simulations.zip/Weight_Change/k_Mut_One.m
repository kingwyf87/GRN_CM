% matrix R with one mutation function
function result = k_Mut_One(mat_R,gene_N)
 
% find the non-zero items in matrix R
vector_R = mat_R(:);
index_non_zero_R = find(vector_R~=0);

if (length(index_non_zero_R)~=0)

    % gernerate random mutation popsitions
    rand_Pos = randi(length(index_non_zero_R),1,1);

    % mutation  
    vector_R(index_non_zero_R(rand_Pos)) = randn(1,1);

    result = reshape(vector_R,gene_N,gene_N);
else
    result = mat_R;
end
    
