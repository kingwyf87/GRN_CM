function mat2csv(filename)

M = load(filename);
C = struct2cell(M);
Mat = C{1};
filename1 = strcat(filename,'.csv');
csvwrite(filename1,Mat);