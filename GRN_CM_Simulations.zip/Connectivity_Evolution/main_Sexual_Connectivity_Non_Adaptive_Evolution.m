function main_Sexual_Connectivity_Non_Adaptive_Evolution()

%% clear work space
clc
clear

%% load data
load gene_Satble_Net_N10_a100_Y_Founder_c025

%% set parameters

% set number of generation cycles
num_Cycle = 50;

% set maximum gernation
max_G = 1000;

% set gernation for each cycle
cycle_G = max_G/num_Cycle;
 
% set gene networksize
size_Net = 10000;

% set gene number
gene_N = 10;

% set network connectivity
c = 0.25;

% set activation constant
a = 100;

% set iteration times for stable development
iter_T = 100;

% set time interval
tau = 10;

% set init Pop
gene_Net = gene_Net_N10;

%% asexual evolution with relaxed selection for stability
for n = 1:num_Cycle
    
    n
    
    for g = 1:cycle_G

        g

        if(g==cycle_G-1)
            flag_Stability = 0;    
        else
            flag_Stability = 1;
        end

        % popluation reproduction
        counter_Pop = 0;
        new_Pop = cell(1,size_Net);
        while (counter_Pop<size_Net)

            % gernerate two random position
            pos_Rand = randi([1,size_Net],1,2);

            % target genotypes recombination
            [select_Net1] = gene_Net{pos_Rand(1)};
            [select_Net2] = gene_Net{pos_Rand(2)};
            [select_W1] = select_Net1{2};
            [select_W2] = select_Net2{2};
            [init_S] = select_Net1{1};
            
            index = binornd(1,0.5,1,gene_N);
            for m = 1:gene_N
                if index(m)==1
                    select_W(m,:) = select_W1(m,:);
                else
                    select_W(m,:) = select_W2(m,:);
                end
            end  

            % one mutation      
            [mut_W] = k_Mut_One(select_W,gene_N); 

            % test EQ for W
            dev_S = net_Dev(mut_W,init_S,iter_T,a);
            if (is_Equilibrium(dev_S,iter_T,gene_N,tau))               
                stable_Flag = 1;
            else
                stable_Flag = 0;
            end

            % selection for W
            if(flag_Stability==1)
                if (stable_Flag==1)
                    counter_Pop = counter_Pop+1;
                    [new_Pop{counter_Pop}{2}] = mut_W;
                    [new_Pop{counter_Pop}{1}] = init_S;
                end
            else
                counter_Pop = counter_Pop+1;
                [new_Pop{counter_Pop}{2}] = mut_W;
                [new_Pop{counter_Pop}{1}] = init_S;
            end

        end
        
        gene_Net = new_Pop;

    end
    
    % record network connectivity of each cycle
    [c_Pop_All(n)] = mean(cal_Net_Connectivity(gene_Net,size_Net,gene_N));
    
end

%% save results
temp_Str = num2str(c);
counter = 0;
for n = 1:length(temp_Str)
    if (temp_Str(n)~='.')
        counter = counter+1;
        str_c(counter) = temp_Str(n);
    end
end
save_Name = ['results_Sexual_Pop',num2str(size_Net),'_G',num2str(max_G),'_N',num2str(gene_N),'_c',str_c,'_numCycle',num2str(num_Cycle)];
save (save_Name) 