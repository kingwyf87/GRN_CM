function Figure_Plot()

% % % % % % % % % % % % % % % % 
% %       Plot Results      % %
% % % % % % % % % % % % % % % %

%%
load P_CM_S0_N20_K4_a100
load P_CM_S1_N20_K4_a100
load P_CM_S2_N20_K4_a100
load P_CM_S3_N20_K4_a100
load P_CM_S4_N20_K4_a100
P_CM_S5_N20_K4 = [P_CM_S0_N20;P_CM_S1_N20;P_CM_S2_N20;P_CM_S3_N20;P_CM_S4_N20];
%%
load P_CM_S0_N5_a100
load P_CM_S1_N5_a100
load P_CM_S2_N5_a100
load P_CM_S3_N5_a100
load P_CM_S4_N5_a100
P_CM_S5_N5_K2 = [P_CM_S0_N5;P_CM_S1_N5;P_CM_S2_N5;P_CM_S3_N5;P_CM_S4_N5];
%%
d_Max = 4;
for n = 1:100
    Distr_All_N5_K2(n,:) = Pos_Distr_All_N5{n}(1:d_Max+1);
end
save Distr_All_N5_K2 Distr_All_N5_K2
%%
d_Max = 5;
for n = 1:100
    Distr_All_N20_K4(n,:) = Pos_Distr_All_N20{n}(1:d_Max+1);
end
save Distr_All_N20_K4 Distr_All_N20_K4
%%
d_Max = 4;

errorbar(0:d_Max,mean(R_CM_S5_N5_K2,2),1.96*std(R_CM_S5_N20_K2,0,2),'Color',[0 0 1],'LineWidth',1.5)
hold on
errorbar(0:d_Max,mean(P_CM_S5_N20_K4,2),1.96*std(P_CM_S5_N20_K4,0,2),'Color',[1 0 0],'LineWidth',1.5)
hold on
title('Test for Compensatory Mutation Positions','FontSize',20);
ylabel('Mean Frequency of Compensatory Mutations (10,000 Sample Networks)','FontSize',15);
xlabel('Distance from Deleterious Mutation','FontSize',15);
ylim([0 0.28])
xlim([-0.1 4.1])
legend1 = legend('N_{gene} = 5, Network Connectivity = 0.4','N_{gene} = 20, Network Connectivity = 0.1');
set(legend1,'FontSize',15);
hold off
%%
set(gcf, 'color', [1 1 1])
export_fig('Figure4a.pdf')


%%
load Distr_All_N20_K4
load Distr_CM_N20_K4
%
d_Max = 7;
%%
errorbar(0:d_Max-1,mean(Distr_All_N20',2),1.96*std(Distr_All_N20',0,2),'Color',[0 0 1],'LineWidth',1.5)
hold on
errorbar(0:d_Max-1,mean(Distr_CM_N20',2),1.96*std(Distr_CM_N20',0,2),'Color',[1 0 0],'LineWidth',1.5)
hold on
% ylim([-0.01 0.5])
% xlim([-0.1 6.1])
legend1 = legend('All Mutations','CM Mutations');
set(legend1,'FontSize',15);
title('Test for Distribution of Different Mutations','FontSize',20);
ylabel('Mean Frequency of Compensatory Mutations (10,000 Sample Networks)','FontSize',15);
xlabel('Distance from Deleterious Mutation','FontSize',15);
hold off
%%
set(gcf, 'color', [1 1 1])
export_fig('Figure4b.pdf')


%%
% % % % % % % % % % % % % % % % 
% % %  Plot Results N = 05  % %
% % % % % % % % % % % % % % % %
% 
% load R_CM_S0_N5_K2;
% load R_CM_S1_N5_K2
% load R_CM_S2_N5_K2
% load R_CM_S3_N5_K2
% load R_CM_S4_N5_K2
% 
% d_Max = 4;
% 
% mean_R = [mean(R_CM_S0_N5),mean(R_CM_S1_N5),mean(R_CM_S2_N5),mean(R_CM_S3_N5),mean(R_CM_S4_N5)];
% std_R = [std(R_CM_S0_N5),std(R_CM_S1_N5),std(R_CM_S2_N5),std(R_CM_S3_N5),std(R_CM_S4_N5)];
% 
% figure;
% plot(0:d_Max,mean_R,'Color',[1 0 0],'LineWidth',1.5);
% hold on;
% title('Test for Compensatory Mutation Positions (N = 5 K = 2)');
% ylabel('Frequency (10,000 Sample Networks)');
% xlabel('Distance from Deleterious Mutation');
% legend('Compensatory Mutations');
% hold off;
% 
% errorbar(0:d_Max,mean_R,std_R)
% 
% % % % % % % % % % % % % % % % 
% % %  Plot Results N = 20  % %
% % % % % % % % % % % % % % % %
% 
% load R_CM_S0_N20_K2;
% load R_CM_S1_N20_K2
% load R_CM_S2_N20_K2
% load R_CM_S3_N20_K2
% load R_CM_S4_N20_K2
% 
% d_Max = 4;
% 
% mean_R = [mean(R_CM_S0_N20),mean(R_CM_S1_N20),mean(R_CM_S2_N20),mean(R_CM_S3_N20),mean(R_CM_S4_N20)];
% std_R = [std(R_CM_S0_N20),std(R_CM_S1_N20),std(R_CM_S2_N20),std(R_CM_S3_N20),std(R_CM_S4_N20)];
% 
% figure;
% plot(0:d_Max,mean_R,'Color',[1 0 0],'LineWidth',1.5);
% hold on;
% title('Test for Compensatory Mutation Positions (N = 20 K = 2)');
% ylabel('Frequency (10,000 Sample Networks)');
% xlabel('Distance from Deleterious Mutation');
% legend('Compensatory Mutations');
% hold off;
% 
% errorbar(0:d_Max,mean_R,std_R)
% 
% 
% % % % % % % % % % % % % % % % 
% % %    Plot All Results   % %
% % % % % % % % % % % % % % % %
% d_Max = 4;
% figure;
% errorbar(0:d_Max,mean(R_CM_S5_N5_K2,2),1.96*std(R_CM_S5_N5_K2,0,2),'Color',[0.168627455830574 0.505882382392883 0.337254911661148],'LineWidth',1.5)
% hold on
% errorbar(0:d_Max,mean(R_CM_S5_N20_K2,2),1.96*std(R_CM_S5_N20_K2,0,2),'Color',[0 0 1],'LineWidth',1.5)
% hold on
% errorbar(0:d_Max,mean(R_CM_S5_N20_K4,2),1.96*std(R_CM_S5_N20_K4,0,2),'Color',[1 0 0],'LineWidth',1.5)
% hold on
% title('Test for Compensatory Mutation Positions (95% Confidence Interval)' );
% ylabel('Mean Frequency (10,000 Sample Networks)');
% xlabel('Distance from Deleterious Mutation');
% ylim([0 0.27])
% legend('Compensatory Mutations N = 5 K = 2','Compensatory Mutations N = 20 K = 2','Compensatory Mutations N = 20 K = 4');
% hold off

%%
clear
clc
%%
gene_N = 40;
K = 6;
c = K/gene_N;
d_Max = 10;
d_Max_CM = 6;
d_Max_DM = 9;
max_T = 100;
size_Net = 10000;
T = 100;
%%
load(['Pos_Distr_CM_N',num2str(gene_N),'_K',num2str(c*gene_N)])
load(['Pos_Distr_All_N',num2str(gene_N),'_K',num2str(c*gene_N)])
%% Gruop Results
for n = 1:max_T
    % CM
    len_CM = length(Pos_Distr_CM{n});
    Distr_CM(n,1:len_CM) = Pos_Distr_CM{n};
    if (len_CM<d_Max)
        Distr_CM(n,len_CM+1:d_Max) = 0;
    end
    % All
    len_All = length(Pos_Distr_All{n});
    Distr_All(n,1:len_All) = Pos_Distr_All{n};
    if (len_All<d_Max)
        Distr_All(n,len_All+1:d_Max) = 0;
    end      
end
mean_All = mean(Distr_All);
mean_CM = mean(Distr_CM);
std_All = std(Distr_All,0,1);
std_CM = std(Distr_CM,0,1);
%% plot figure
errorbar(0:d_Max_DM,mean_All(1:d_Max_DM+1),1.96*std_All(1:d_Max_DM+1)/sqrt(T),'Color',[0 0 1],'LineWidth',1.5)
hold on
errorbar(0:d_Max_CM,mean_CM(1:d_Max_CM+1),1.96*std_CM(1:d_Max_CM+1)/sqrt(T),'Color',[1 0 0],'LineWidth',1.5)
hold off
title({'Test for Distribution of Mutations' ,strcat(' [Pop=',num2str(size_Net),', N=',num2str(gene_N),', c=',num2str(c),']')},...
    'FontSize',30,...
    'FontName','Arial');
xlabel(['Distance from Deleterious Mutation Site'],...
    'FontSize',25,...
    'FontName','Arial');
ylabel(['Mean Frequency'],...
    'FontSize',25,...
    'FontName','Arial');
text1 = ['Distribution of All Mutations'];
text2 = ['Distribution of Compensatory Mutations'];
legend1 = legend(text1,text2);
set(legend1,'Location','NorthEast','FontSize',25,'FontName','Arial');
ylim([0,0.55])
xlim([0-0.1,d_Max_DM+0.1])
set(gca,'XTick',[0:d_Max_DM],'FontName','Arial','FontSize',20)
hold off


