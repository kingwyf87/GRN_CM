function [num_CM_All] = cal_Num_CM_Asexual_Non_Adaptive_Evolution_Flipping(gene_Net,size_Net,gene_N,max_G,cycle_G,a,iter_T,tau)

%% asexual evolution with relaxed selection for stability
counter_Record = 0;
for g = 1:max_G
      
    g
    
    if (mod(g,cycle_G)==0)
        flag_Stability = 0;
        pop_Stability = ones(size_Net,1);
    else
        flag_Stability = 1;
    end  
    
    % popluation reproduction
    counter_Pop = 0;
    counter_CM = 0;
    new_Pop = cell(1,size_Net);
    while (counter_Pop<size_Net)

        % gernerate one random position
        pos_Rand = randi([1,size_Net],1,1);
        [select_Net] = gene_Net{pos_Rand};
        [init_S] = select_Net{1};
        [select_W] = select_Net{2};

        % one mutation      
        [mut_W] = k_Mut_One(select_W,gene_N); 

        % test EQ for W
        dev_S = net_Dev(mut_W,init_S,iter_T,a);
        if (is_Equilibrium(dev_S,iter_T,gene_N,tau))               
            stable_Flag = 1;
        else
            stable_Flag = 0;
        end

        % selection for W
        if(flag_Stability==1)
            if (stable_Flag==1)
                counter_Pop = counter_Pop+1;
                [new_Pop{counter_Pop}{2}] = mut_W;
                [new_Pop{counter_Pop}{1}] = init_S;
            end
            if (g~=1&&mod(g-1,cycle_G)==0)
                if(pop_Stability(pos_Rand)==0)
                   counter_CM = counter_CM+1; 
                end
            end
        else
            counter_Pop = counter_Pop+1;
            [new_Pop{counter_Pop}{2}] = mut_W;
            [new_Pop{counter_Pop}{1}] = init_S;
            if (stable_Flag==0)
                pop_Stability(counter_Pop) = 0;
            end
        end

    end

    gene_Net = new_Pop;
        
    % record number of CM in each cycle
    if (g~=1&&mod(g-1,cycle_G)==0)
        counter_Record = counter_Record+1;
        num_CM_All(counter_Record) = counter_CM;
    end
    
end