function test_CMs_Position_N10()

% clear workspace
clc
clear

% load data
load gene_Satble_Net_N10_a100_K4;

% set gene numbers
gene_N = 10;

% set maximal independent runs
max_T = 100;

% set activation constant
a = 100;

% set iteration times for stable development
iter_T = 100;

% set time interval
tau = 10;

% set gene network size
size_Init = 10000;

% resample the network
size_Net = 10*size_Init;
gene_Net_N10_R = net_Increase(gene_Net_N10,size_Net);

% Test
for n = 1:max_T
    
    n
    [P_CM_S0_N10(n),P_CM_S1_N10(n),P_CM_S2_N10(n),P_CM_S3_N10(n),P_CM_S4_N10(n)] = cal_CMs_Position(gene_Net_N10_R,size_Net,gene_N,iter_T,tau,a,size_Init);
    
end

filename = strcat('P_CM_S0_N10_a',num2str(a));
save(filename,'P_CM_S0_N10')
filename = strcat('P_CM_S1_N10_a',num2str(a));
save(filename,'P_CM_S1_N10')
filename = strcat('P_CM_S2_N10_a',num2str(a));
save(filename,'P_CM_S2_N10')
filename = strcat('P_CM_S3_N10_a',num2str(a));
save(filename,'P_CM_S3_N10')
filename = strcat('P_CM_S4_N10_a',num2str(a));
save(filename,'P_CM_S4_N10')

