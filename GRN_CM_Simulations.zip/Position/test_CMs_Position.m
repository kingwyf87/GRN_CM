function test_CMs_Position(gene_N,c,a,max_T,part)

% clear workspace
clc

% load data
load(['gene_Satble_Net_N',num2str(gene_N),'_a',num2str(a),'_K',num2str(c*gene_N)])

% % set gene numbers
% gene_N = 40;
% 
% % set maximal independent runs
% max_T = 100;
% 
% % set activation constant
% a = 100;

% set iteration times for stable development
iter_T = 100;

% set time interval
tau = 10;

% set gene network size
size_Init = 10000;

% resample the network
size_Net = 10*size_Init;
gene_Net_R = net_Increase(gene_Net,size_Net);

% Test
for n = 1:max_T
    
    n
    
    [P_CM_S0(n),P_CM_S1(n),P_CM_S2(n),P_CM_S3(n),P_CM_S4(n)] = cal_CMs_Position(gene_Net_R,size_Net,gene_N,iter_T,tau,a,size_Init);

    filename = strcat('P_CM_S0_N',num2str(gene_N),'_K',num2str(gene_N*c),'_a',num2str(a),'_Part',num2str(part));
    save(filename,'P_CM_S0')
    filename = strcat('P_CM_S1_N',num2str(gene_N),'_K',num2str(gene_N*c),'_a',num2str(a),'_Part',num2str(part));
    save(filename,'P_CM_S1')
    filename = strcat('P_CM_S2_N',num2str(gene_N),'_K',num2str(gene_N*c),'_a',num2str(a),'_Part',num2str(part));
    save(filename,'P_CM_S2')
    filename = strcat('P_CM_S3_N',num2str(gene_N),'_K',num2str(gene_N*c),'_a',num2str(a),'_Part',num2str(part));
    save(filename,'P_CM_S3')
    filename = strcat('P_CM_S4_N',num2str(gene_N),'_K',num2str(gene_N*c),'_a',num2str(a),'_Part',num2str(part));
    save(filename,'P_CM_S4')    
    
end



