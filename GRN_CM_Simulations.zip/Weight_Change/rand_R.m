% R matrix initialize function
function result_R = rand_R(N,c)

% number of non-zero items
N_non_zero = floor(N^2*c+0.5);

% number of zero items
N_zero = N^2 - N_non_zero; 

temp_R = randn(N*N,1);

index = randperm(N*N);

for i = 1:N_zero
    temp_R(index(i)) = 0;
end

result_R = reshape(temp_R,N,N);