function [c_Pop_All,c_Pop] = cal_Connectivity_Sexual_Non_Adaptive_Evolution_Flipping_Pyramid(gene_Net,size_Net,gene_N,max_G,cycle_G,a,iter_T,tau)

%% asexual evolution with relaxed selection for stability
counter_C = 0;
for g = 1:max_G
    
    g

    % relaxed selection in every cycle_G generation 
    if (mod(g,cycle_G)==0)
        flag_Stability = 0;
	else
        flag_Stability = 1;
    end    
    
    % popluation reproduction
    counter_Pop = 0;
    new_Pop = cell(1,size_Net);
    while (counter_Pop<size_Net)

        % gernerate two random position
        pos_Rand = randi([1,size_Net],1,2);

        % target genotypes recombination
        [init_S] = gene_Net{pos_Rand(1)}{1};
        index = binornd(1,0.5,1,gene_N);
        for m = 1:gene_N
            if index(m)==1
                select_W(m,:) = gene_Net{pos_Rand(1)}{2}(m,:);
            else
                select_W(m,:) = gene_Net{pos_Rand(2)}{2}(m,:);
            end
        end  

        % one mutation      
        [mut_W] = k_Mut_One(select_W,gene_N); 

        % test EQ for W
        dev_S = net_Dev(mut_W,init_S,iter_T,a);
        if (is_Equilibrium(dev_S,iter_T,gene_N,tau))               
            stable_Flag = 1;
        else
            stable_Flag = 0;
        end

        % selection for W
        if(flag_Stability==1)
            if (stable_Flag==1)
                counter_Pop = counter_Pop+1;
                [new_Pop{counter_Pop}{2}] = mut_W;
                [new_Pop{counter_Pop}{1}] = init_S;
            end
        else
            counter_Pop = counter_Pop+1;
            [new_Pop{counter_Pop}{2}] = mut_W;
            [new_Pop{counter_Pop}{1}] = init_S;
        end

    end

    gene_Net = new_Pop;

	% record network connectivity every 50 generations
    if (mod(g-1,50)==0&&g~=1)
        counter_C = counter_C+1;
        [c_Pop_All(counter_C)] = mean(cal_Net_Connectivity(gene_Net,size_Net,gene_N));
    end
    
end

c_Pop = gene_Net;