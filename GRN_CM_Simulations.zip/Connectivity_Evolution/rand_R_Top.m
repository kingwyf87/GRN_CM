% R matrix initialize function
function result_R = rand_R_Top(N,c,self_edges)

% number of non-zero items
N_non_zero = N;

temp_R = zeros(N,N);
index_non_zero = randperm(N);
index_non_zero(end+1) = index_non_zero(1);

for n = 1:N_non_zero
    temp_R(index_non_zero(n+1),index_non_zero(n)) = randn(1,1);
end

for n = 1:N
    if(self_edges(n)==1)
        temp_R(n,n) = randn(1,1);
    end
end

result_R = temp_R;