function [w_All,w_Self,w_Non_Self] = cal_Weight_Effect_Distribution(gene_N,size_Net,iter_T,c,a,tau)

counter_All = 0;
counter_Self = 0;
counter_Non_Self = 0;
while (counter_All<size_Net)
    
    [init_S,select_W] = init_NetDev(gene_N,iter_T,c,a,tau);
     
    for i = 1:gene_N
        for j = 1:gene_N            
            if (select_W(i,j)~=0) 
                if (counter_All>size_Net)
                    break;
                else
                    counter_All = counter_All+1;
                    w_All(counter_All) = select_W(i,j);
                    if (i==j)
                        counter_Self = counter_Self+1;
                        w_Self(counter_Self) = select_W(i,j);
                    else
                        counter_Non_Self = counter_Non_Self+1;
                        w_Non_Self(counter_Non_Self) = select_W(i,j);
                    end
                end
            end           
        end
    end
    
end
