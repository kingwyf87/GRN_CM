function [file_Name] = generate_File_Name_Flipping(gene_N,c,num_Cycle)

%% save results
temp_Str = num2str(c);
counter = 0;
for n = 1:length(temp_Str)
    if (temp_Str(n)~='.')
        counter = counter+1;
        str_c(counter) = temp_Str(n);
    end
end
file_Name = ['c_Pop_All_Flipping_Founder_N',num2str(gene_N),'_c',str_c,'_numCycle',num2str(num_Cycle)];
