function test_Weight_Effect_Distribution_CM(gene_N,max_T,a,c)

%% clear work space
clc

%% load data
load(['gene_Satble_Net_N',num2str(gene_N),'_a',num2str(a),'_K',num2str(c*gene_N)])

%% set parameters

% set gene number
% gene_N = 5;
% set maximum of independent runs
% max_T = 100;
% set activation constant
% a = 100;

% set gene networksize
size_Net = 10000;

% set iteration times for stable development
iter_T = 100;

% set time interval
tau = 10;

%% Testing
for t = 1:max_T
   
    t
    
    [w_CM_All{t},w_CM_Self{t},w_CM_Non_Self{t}] = cal_Weight_Effect_Distribution_CM(gene_Net,size_Net,gene_N,a,iter_T,tau);
    
end

%% save results
temp_Str = num2str(c);
counter = 0;
for n = 1:length(temp_Str)
    if (temp_Str(n)~='.')
        counter = counter+1;
        str_c(counter) = temp_Str(n);
    end
end
fliename = ['w_CM_All_N' num2str(gene_N) '_c' str_c '_max_T' num2str(max_T)];
save (fliename,'w_CM_All')
fliename = ['w_CM_Self_N' num2str(gene_N) '_c' str_c '_max_T' num2str(max_T)];
save (fliename,'w_CM_Self')
fliename = ['w_CM_Non_Self_N' num2str(gene_N) '_c' str_c '_max_T' num2str(max_T)];
save (fliename,'w_CM_Non_Self')