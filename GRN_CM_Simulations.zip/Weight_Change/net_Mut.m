% gene notwork mutation function
function [mut_Net] = net_Mut(gene_Net,size_Net,gene_N)

% gene notwork mutation
for n = size_Net:-1:1

    % set inicial network 
    mut_Net{n}{1} = gene_Net{n}{1};
    mut_Net{n}{2} = gene_Net{n}{2};
    
    % generate random mutation position
    mut_Pos = randi(gene_N,[1,2]);
    while (mut_Net{n}{2}(mut_Pos(1),mut_Pos(2))==0)
        mut_Pos = randi(gene_N,[1,2]);
    end
      
    % network mutated 
    mut_Net{n}{2}(mut_Pos(1),mut_Pos(2)) = randn(1,1);
             
end