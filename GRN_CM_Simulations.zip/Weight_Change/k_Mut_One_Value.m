% matrix R with one mutation function
function [result_R,result_Value] = k_Mut_One_Value(mat_R,gene_N)
 
% find the non-zero items in matrix R
vector_R = mat_R(:);
index_non_zero_R = find(vector_R~=0);

if (~isempty(index_non_zero_R))

    % gernerate random mutation popsitions
    rand_Pos = randi(length(index_non_zero_R),1,1);

    % mutation
    result_Value = randn(1,1);
    vector_R(index_non_zero_R(rand_Pos)) = result_Value;

    result_R = reshape(vector_R,gene_N,gene_N);
    
else
    result_R = mat_R;
    result_Value = 0;
end
    
