function [mat_Dis] = net_min_Dis_Calculate(index_x1,index_y1,index_x2,index_y2,mat_R)

if (index_x1==index_x2&&index_y1==index_y2)
    
    mat_Dis = 0;
    
elseif (index_x1==index_y2&&index_x2==index_y1)
    mat_Dis = 1;
else   
    [col,row] = size(mat_R);
    temp_M = zeros(col,row);
    for n=1:row
        for m=1:col
            if (mat_R(n,m)~=0)
               temp_M(n,m)=1;
               temp_M(m,n)=1;
            end
        end
    end
    
    [dist, path, pred] = graphshortestpath(sparse(temp_M),index_x1,index_x2,'Directed',false,'Method','BFS');
    
    if (dist==inf)
        mat_Dis = inf;
    else
       if (index_x1==index_x2)
            mat_Dis = 1;
       elseif (path(2)~=index_y1&&path(end-1)~=index_y2)
          mat_Dis = dist+1;
       elseif (path(2)==index_y1&&path(end-1)==index_y2)
           mat_Dis = dist-1;
       else
           mat_Dis = dist;
       end
    end
end
                  
%     
% %     mat_Dis = graphshortestpath(sparse(mat_R),index_x2,index_y1,'Method','BFS') + 1;
%     downstream_Dis = graphshortestpath(sparse(mat_R),index_x2,index_y1,'Method','BFS') + 1;
%     
%     upstream_Dis = graphshortestpath(sparse(mat_R),index_x1,index_y2,'Method','BFS') + 1;
%  
%     mat_Dis = min(downstream_Dis,upstream_Dis);
end


