function [mut_Value_All,mut_Value_Self,mut_Value_Non_Self] = cal_Weight_Effect_Distribution_CM(gene_Net,size_Net,gene_N,a,iter_T,tau)

counter_All = 0;
counter_Self = 0;
counter_Non_Self = 0;
while (counter_All<size_Net)
    
	% gernerate one random position
    pos_Rand = randi([1,size_Net],1,1);
    
    % get R and S
    [init_S] = gene_Net{pos_Rand}{1};
    [select_W] = gene_Net{pos_Rand}{2};
              
    % one mutation      
	[mut_W] = k_Mut_One(select_W,gene_N); 

	% test EQ for W
    dev_S = net_Dev(mut_W,init_S,iter_T,a);
    if (is_Equilibrium(dev_S,iter_T,gene_N,tau)==0)
        % one mutation
        [mut_W,mut_Value,mut_Pos] = k_Mut_One_W_Pos(select_W,gene_N);
        % test EQ for W
        dev_S = net_Dev(mut_W,init_S,iter_T,a);
        if (is_Equilibrium(dev_S,iter_T,gene_N,tau)==1)
            counter_All = counter_All+1;
            mut_Value_All(counter_All) = mut_Value;
            if(mut_Pos(1)==mut_Pos(2))
                counter_Self = counter_Self+1;
                mut_Value_Self(counter_Self) = mut_Value;
            else
                counter_Non_Self = counter_Non_Self+1;
                mut_Value_Non_Self(counter_Non_Self) = mut_Value;
            end      
        end
    end
    
end