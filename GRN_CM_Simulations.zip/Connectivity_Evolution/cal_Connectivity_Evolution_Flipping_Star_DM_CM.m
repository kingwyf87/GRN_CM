function [c_DM,c_Pop_DM,c_CM,c_Pop_CM] = cal_Connectivity_Evolution_Flipping_Star_DM_CM(gene_Net,size_Net,gene_N,max_G,cycle_G,a,iter_T,tau)

%% sexual evolution with relaxed selection for stability
counter_DM = 0;
counter_CM = 0;
c_Pop_DM = [];
c_Pop_CM = [];
for g = 1:max_G
    
    g

    % relaxed selection in every cycle_G generation 
    if (mod(g,cycle_G)==0)
        flag_Stability = 0;
        pop_Stability = ones(size_Net,1);
        counter_temp_DM = 0;
        counter_temp_CM = 0;
	else
        flag_Stability = 1;
    end  

    % popluation reproduction
    counter_Pop = 0;
    new_Pop = cell(1,size_Net);
    while (counter_Pop<size_Net)

        % gernerate two random position
        pos_Rand = randi([1,size_Net],1,2);

        % target genotypes recombination
        [init_S] = gene_Net{pos_Rand(1)}{1};
        index = binornd(1,0.5,1,gene_N);
        for m = 1:gene_N
            if index(m)==1
                select_W(m,:) = gene_Net{pos_Rand(1)}{2}(m,:);
            else
                select_W(m,:) = gene_Net{pos_Rand(2)}{2}(m,:);
            end
        end  

        % one mutation      
        [mut_W] = k_Mut_One(select_W,gene_N); 

        % test EQ for W
        dev_S = net_Dev(mut_W,init_S,iter_T,a);
        if (is_Equilibrium(dev_S,iter_T,gene_N,tau))               
            stable_Flag = 1;
        else
            stable_Flag = 0;
        end

        % selection for W
        if(flag_Stability==1)
            if (stable_Flag==1)
                counter_Pop = counter_Pop+1;
                [new_Pop{counter_Pop}{2}] = mut_W;
                [new_Pop{counter_Pop}{1}] = init_S;
            end
            % record c in CM networks
            if (g~=1&&mod(g-1,50)==0)
                if(pop_Stability(pos_Rand(1))==0||pop_Stability(pos_Rand(2))==0)
                    counter_temp_CM = counter_temp_CM+1;
                    temp_c_CM(counter_temp_CM) = sum(sum(mut_W~=0))/gene_N^2; 
                    if (g==max_G)
                        [c_Pop_CM{counter_temp_CM}{2}] = mut_W;
                        [c_Pop_CM{counter_temp_CM}{1}] = init_S;
                    end
                end
            end
        else
            counter_Pop = counter_Pop+1;
            [new_Pop{counter_Pop}{2}] = mut_W;
            [new_Pop{counter_Pop}{1}] = init_S;
            % record c in DM networks
            if (mod(g,50)==0)
                if (stable_Flag==0)
                    pop_Stability(counter_Pop) = 0;
                    counter_temp_DM = counter_temp_DM+1;
                    temp_c_DM(counter_temp_DM) = sum(sum(mut_W~=0))/gene_N^2;
                    if (g==max_G-1)
                        [c_Pop_DM{counter_temp_DM}{2}] = mut_W;
                        [c_Pop_DM{counter_temp_DM}{1}] = init_S;
                    end
                end
            end
        end

    end

    gene_Net = new_Pop;

	% record network connectivity every 50 generations
    if (mod(g-1,50)==0&&g~=1)
        counter_CM = counter_CM+1;
        [c_CM(counter_CM)] = mean(temp_c_CM);
    end
    
	if (mod(g,50)==0)
        counter_DM = counter_DM+1;
        [c_DM(counter_DM)] = mean(temp_c_DM);
    end
    
end