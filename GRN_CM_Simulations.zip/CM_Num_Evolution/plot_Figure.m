function plot_Figure()

%% clear workspace
clear
close all
clc
%% set parameters
num_Cycle_All = [50 25 10 5 1];
gene_N = 10;
c = 0.75;
sex = 'Asexual';
max_G = 1000;
size_Net = 10000;
%% load data
load(generate_File_Name(sex,size_Net,max_G,gene_N,c,num_Cycle_All(1)))
y1 = sum(num_CM_All)/gene_N/num_Cycle_All(1)/20;
load(generate_File_Name(sex,size_Net,max_G,gene_N,c,num_Cycle_All(2)))
y2 = sum(num_CM_All)/gene_N/num_Cycle_All(2)/40;
load(generate_File_Name(sex,size_Net,max_G,gene_N,c,num_Cycle_All(3)))
y3 = sum(num_CM_All)/gene_N/num_Cycle_All(3)/100;
load(generate_File_Name(sex,size_Net,max_G,gene_N,c,num_Cycle_All(4)))
y4 = sum(num_CM_All)/gene_N/num_Cycle_All(4)/200;
load(generate_File_Name(sex,size_Net,max_G,gene_N,c,num_Cycle_All(5)))
y5 = sum(num_CM_All)/gene_N/num_Cycle_All(5)/1000;
%%
num_Cycle_All = [50 25 10 5 1];
gene_N = 10;
c = 0.75;
sex = 'Sexual';
max_G = 1000;
size_Net = 10000;
%% load data
load(generate_File_Name(sex,size_Net,max_G,gene_N,c,num_Cycle_All(1)))
y11 = sum(num_CM_All)/gene_N/num_Cycle_All(1)/20;
load(generate_File_Name(sex,size_Net,max_G,gene_N,c,num_Cycle_All(2)))
y22 = sum(num_CM_All)/gene_N/num_Cycle_All(2)/40;
load(generate_File_Name(sex,size_Net,max_G,gene_N,c,num_Cycle_All(3)))
y33 = sum(num_CM_All)/gene_N/num_Cycle_All(3)/100;
load(generate_File_Name(sex,size_Net,max_G,gene_N,c,num_Cycle_All(4)))
y44 = sum(num_CM_All)/gene_N/num_Cycle_All(4)/200;
load(generate_File_Name(sex,size_Net,max_G,gene_N,c,num_Cycle_All(5)))
y55 = sum(num_CM_All)/gene_N/num_Cycle_All(5)/1000;
%% plot results
figure;
plot((max_G-num_Cycle_All)/max_G,[y1 y2 y3 y4 y5],'Color',[0 0 1],'LineWidth',1.5);
hold on;
plot((max_G-num_Cycle_All)/max_G,[y11 y22 y33 y44 y55],'Color',[1 0 0],'LineWidth',1.5);
hold off;
title({'Test for Number of Compensatory Mutations Under Different Stability Selection Pressure' ,strcat(' [Pop=',num2str(size_Net),', N=',num2str(gene_N),', c=',num2str(c),', G=',num2str(max_G),']')},...
    'FontSize',30,...
    'FontName','Arial');
xlabel('Precentage of Stability Selection During Non-Adaptive Evolution',...
    'FontSize',25,...
    'FontName','Arial');
ylabel(['Number of Compensatory Mutations',sprintf('\n'),'(per locus, per generation)'],...
    'FontSize',25,...
    'FontName','Arial');
text1 = ['N = ' num2str(gene_N),' c = ',num2str(c),'(Asexual)'];
text2 = ['N = ' num2str(gene_N),' c = ',num2str(c),'(Sexual)'];
% legend1 = legend(text1);
legend1 = legend(text1,text2);
set(legend1,'Location','NorthEast','FontSize',25,'FontName','Arial');
set(gca,'FontSize',20)
xlim([0.95 1])
% ylim([0,0.2]);


%% 
clear
close all
clc
%% set parameters
num_Cycle_All = [50 25 10 5 1];
gene_N = 40;
c = 0.76;
max_G = 1000;
%% load data
load(generate_File_Name_Test(gene_N,c,num_Cycle_All(1)))
y1 = sum(num_CM_All)/num_Cycle_All(1)/(max_G/num_Cycle_All(1));
load(generate_File_Name_Test(gene_N,c,num_Cycle_All(2)))
y2 = sum(num_CM_All)/num_Cycle_All(2)/(max_G/num_Cycle_All(2));
load(generate_File_Name_Test(gene_N,c,num_Cycle_All(3)))
y3 = sum(num_CM_All)/num_Cycle_All(3)/(max_G/num_Cycle_All(3));
load(generate_File_Name_Test(gene_N,c,num_Cycle_All(4)))
y4 = sum(num_CM_All)/num_Cycle_All(4)/(max_G/num_Cycle_All(4));
load(generate_File_Name_Test(gene_N,c,num_Cycle_All(5)))
y5 = num_CM_All/num_Cycle_All(5)/(max_G/num_Cycle_All(5));
num_CM_All = [y1;y2;y3;y4;y5];
%% save results
temp_Str = num2str(c);
counter = 0;
for n = 1:length(temp_Str)
    if (temp_Str(n)~='.')
        counter = counter+1;
        str_c(counter) = temp_Str(n);
    end
end
save_Name = ['num_CM_All','_N',num2str(gene_N),'_c',str_c];
save (save_Name,'num_CM_All') 
%%





%% 
clear
close all
clc
%%
num_Cycle_All = [50 25 10 5 1];
gene_N = [5 10 15 20 30 40];
c = 0.76;
max_T = 10;
max_G = 1000;
size_Net = 10000;
%%
load num_CM_All_N5_c076
y1 = num_CM_All;
load num_CM_All_N10_c076
y2 = num_CM_All;
load num_CM_All_N15_c076
y3 = num_CM_All;
load num_CM_All_N20_c076
y4 = num_CM_All;
load num_CM_All_N30_c076
y5 = num_CM_All;
load num_CM_All_N40_c076
y6 = num_CM_All;
%%
% Create figure
figure1 = figure;
axes1 = axes('Parent',figure1,'YScale','log','YMinorTick','on',...
    'FontSize',20);
box(axes1,'on');
hold(axes1,'all');
errorbar(1./num_Cycle_All,mean(y1,2),std(y1,1,2)*1.96./sqrt(max_T),'Color',[0.75 0 0.75],'LineWidth',1.5);
hold on
errorbar(1./num_Cycle_All,mean(y2,2),std(y2,1,2)*1.96./sqrt(max_T),'Color',[0.5 0 0],'LineWidth',1.5);
hold on;
errorbar(1./num_Cycle_All,mean(y3,2),std(y3,1,2)*1.96./sqrt(max_T),'Color',[0.5 0 0.5],'LineWidth',1.5);
hold on;
errorbar(1./num_Cycle_All,mean(y4,2),std(y4,1,2)*1.96./sqrt(max_T),'Color',[0.168627455830574 0.505882382392883 0.337254911661148],'LineWidth',1.5);
hold on;
errorbar(1./num_Cycle_All,mean(y5,2),std(y5,1,2)*1.96./sqrt(max_T),'Color',[0 0 1],'LineWidth',1.5);
hold on;
errorbar(1./num_Cycle_All,mean(y6,2),std(y6,1,2)*1.96./sqrt(max_T),'Color',[1 0 0],'LineWidth',1.5);
hold off;
title({'Test for Number of Compensatory Mutations Under Different Stability Selection Pressure (Asexual)' ,strcat(' [Pop=',num2str(size_Net),', c=',num2str(c),', G=',num2str(max_G),']')},...
    'FontSize',30,...
    'FontName','Arial');
xlabel('Strength of Stability Selection During Non-Adaptive Evolution (Low \rightarrow High)',...
    'FontSize',25,...
    'FontName','Arial');
ylabel(['Number of Compensatory Mutations',sprintf('\n'),'(per locus, per generation)'],...
    'FontSize',25,...
    'FontName','Arial');
text1 = ['N = ' num2str(gene_N(1))];
text2 = ['N = ' num2str(gene_N(2))];
text3 = ['N = ' num2str(gene_N(3))];
text4 = ['N = ' num2str(gene_N(4))];
text5 = ['N = ' num2str(gene_N(5))];
text6 = ['N = ' num2str(gene_N(6))];
legend1 = legend(text1,text2,text3,text4,text5,text6);
set(legend1,'Location','NorthEast','FontSize',25,'FontName','Arial');
set(gca,'FontSize',20)
xlim([0 1.02])
ylim([0.005,20]);


%% Flipping 
clear
close all
clc
%% set parameters
num_Cycle_All = [500 200 100 50 25 10 5 2];
gene_N_All = [5 10 15 20 30 40];
c = 0.76;
max_G = 1000;
size_Net = 10000;
for m = 1:length(gene_N_All)
    %% load data
    load(generate_File_Name_Test_Flipping(gene_N_All(m),c,num_Cycle_All(1)))
    y1 = sum(num_CM_All)/(max_G/num_Cycle_All(1));
    % y1 = num_CM_All(end,:);
    load(generate_File_Name_Test_Flipping(gene_N_All(m),c,num_Cycle_All(2)))
    y2 = sum(num_CM_All)/(max_G/num_Cycle_All(2));
    % y2 = num_CM_All(end,:);
    load(generate_File_Name_Test_Flipping(gene_N_All(m),c,num_Cycle_All(3)))
    y3 = sum(num_CM_All)/(max_G/num_Cycle_All(3));
    % y3 = num_CM_All(end,:);
    load(generate_File_Name_Test_Flipping(gene_N_All(m),c,num_Cycle_All(4)))
    y4 = sum(num_CM_All)/(max_G/num_Cycle_All(4));
    % y4 = num_CM_All(end,:);
    load(generate_File_Name_Test_Flipping(gene_N_All(m),c,num_Cycle_All(5)))
    y5 = sum(num_CM_All)/(max_G/num_Cycle_All(5));
    % y5 = num_CM_All(end,:);
    load(generate_File_Name_Test_Flipping(gene_N_All(m),c,num_Cycle_All(6)))
	y6 = sum(num_CM_All)/(max_G/num_Cycle_All(6));
    % y6 = num_CM_All(end,:);
    load(generate_File_Name_Test_Flipping(gene_N_All(m),c,num_Cycle_All(7)))
	y7 = sum(num_CM_All)/(max_G/num_Cycle_All(7));
    % y7 = num_CM_All(end,:);
	load(generate_File_Name_Test_Flipping(gene_N_All(m),c,num_Cycle_All(8)))
	y8 = sum(num_CM_All)/(max_G/num_Cycle_All(8));
    % y8 = num_CM_All(end,:);  
% 	load(generate_File_Name_Test_Flipping(gene_N_All(m),c,num_Cycle_All(9)))
% 	y9 = sum(num_CM_All)/(max_G/num_Cycle_All(9));
%     % y9 = num_CM_All(end,:);  
    num_CM_All = [y1;y2;y3;y4;y5;y6;y7;y8];
    %% save results
    temp_Str = num2str(c);
    counter = 0;
    for n = 1:length(temp_Str)
        if (temp_Str(n)~='.')
            counter = counter+1;
            str_c(counter) = temp_Str(n);
        end
    end
    save_Name = ['num_CM_All_Flipping','_N',num2str(gene_N_All(m)),'_c',str_c];
    save (save_Name,'num_CM_All') 
end
%%
%% 
clear
close all
clc
%%
num_Cycle_All = [500 200 100 50 25 10 5 2];
gene_N = [5 10 15 20 30 40];
c = 0.76;
max_T = 10;
max_G = 1000;
size_Net = 10000;
%%
load num_CM_All_Flipping_N5_c076
y1 = num_CM_All;
load num_CM_All_Flipping_N10_c076
y2 = num_CM_All;
load num_CM_All_Flipping_N15_c076
y3 = num_CM_All;
load num_CM_All_Flipping_N20_c076
y4 = num_CM_All;
load num_CM_All_Flipping_N30_c076
y5 = num_CM_All;
load num_CM_All_Flipping_N40_c076
y6 = num_CM_All;
%%
% Create figure
figure1 = figure;
axes1 = axes('Parent',figure1,'XScale','log','YMinorTick','on',...
    'FontSize',20);
box(axes1,'on');
hold(axes1,'all');
% num_Cycle_All = 1 - max_G./num_Cycle_All./max_G;
errorbar(1./num_Cycle_All,mean(y1,2),std(y1,1,2)*1.96./sqrt(max_T),'Color',[0.75 0 0.75],'LineWidth',1.5);
hold on
errorbar(1./num_Cycle_All,mean(y2,2),std(y2,1,2)*1.96./sqrt(max_T),'Color',[0.5 0 0],'LineWidth',1.5);
hold on;
errorbar(1./num_Cycle_All,mean(y3,2),std(y3,1,2)*1.96./sqrt(max_T),'Color',[0.5 0 0.5],'LineWidth',1.5);
hold on;
errorbar(1./num_Cycle_All,mean(y4,2),std(y4,1,2)*1.96./sqrt(max_T),'Color',[0.168627455830574 0.505882382392883 0.337254911661148],'LineWidth',1.5);
hold on;
errorbar(1./num_Cycle_All,mean(y5,2),std(y5,1,2)*1.96./sqrt(max_T),'Color',[0 0 1],'LineWidth',1.5);
hold on;
errorbar(1./num_Cycle_All,mean(y6,2),std(y6,1,2)*1.96./sqrt(max_T),'Color',[1 0 0],'LineWidth',1.5);
hold off;
title({'Test for Number of Compensatory Mutations Under Different Stability Selection Pressure (Asexual)' ,strcat(' [Pop=',num2str(size_Net),', c=',num2str(c),', G=',num2str(max_G),']')},...
    'FontSize',30,...
    'FontName','Arial');
xlabel('Strength of Stability Selection During Evolution (Low \rightarrow High)',...
    'FontSize',25,...
    'FontName','Arial');
ylabel(['Frequency of Compensatory Mutations',sprintf('\n'),'(per individual, per relaxed generation)'],...
    'FontSize',25,...
    'FontName','Arial');
text1 = ['N = ' num2str(gene_N(1))];
text2 = ['N = ' num2str(gene_N(2))];
text3 = ['N = ' num2str(gene_N(3))];
text4 = ['N = ' num2str(gene_N(4))];
text5 = ['N = ' num2str(gene_N(5))];
text6 = ['N = ' num2str(gene_N(6))];
legend1 = legend(text1,text2,text3,text4,text5,text6);
set(legend1,'Location','NorthEast','FontSize',25,'FontName','Arial');
set(gca,'FontSize',20)
xlim([0 1.02])
ylim([0.005,20]);



%% Flipping Total
clear
close all
clc
%% set parameters
num_Cycle_All = [500 200 100 50 25 10 5 2];
gene_N_All = [5 10 15 20 30 40];
c = 0.76;
max_G = 1000;
size_Net = 10000;
for m = 1:length(gene_N_All)
    %% load data
    load(generate_File_Name_Test_Flipping(gene_N_All(m),c,num_Cycle_All(1)))
    y1 = sum(num_CM_All);
    % y1 = num_CM_All(end,:);
    load(generate_File_Name_Test_Flipping(gene_N_All(m),c,num_Cycle_All(2)))
    y2 = sum(num_CM_All);
    % y2 = num_CM_All(end,:);
    load(generate_File_Name_Test_Flipping(gene_N_All(m),c,num_Cycle_All(3)))
    y3 = sum(num_CM_All);
    % y3 = num_CM_All(end,:);
    load(generate_File_Name_Test_Flipping(gene_N_All(m),c,num_Cycle_All(4)))
    y4 = sum(num_CM_All);
    % y4 = num_CM_All(end,:);
    load(generate_File_Name_Test_Flipping(gene_N_All(m),c,num_Cycle_All(5)))
    y5 = sum(num_CM_All);
    % y5 = num_CM_All(end,:);
    load(generate_File_Name_Test_Flipping(gene_N_All(m),c,num_Cycle_All(6)))
	y6 = sum(num_CM_All);
    % y6 = num_CM_All(end,:);
    load(generate_File_Name_Test_Flipping(gene_N_All(m),c,num_Cycle_All(7)))
	y7 = sum(num_CM_All);
    % y7 = num_CM_All(end,:);
	load(generate_File_Name_Test_Flipping(gene_N_All(m),c,num_Cycle_All(8)))
	y8 = sum(num_CM_All);
    % y8 = num_CM_All(end,:);  
% 	load(generate_File_Name_Test_Flipping(gene_N_All(m),c,num_Cycle_All(9)))
% 	y9 = sum(num_CM_All)/(max_G/num_Cycle_All(9));
%     % y9 = num_CM_All(end,:);  
    num_CM_All = [y1;y2;y3;y4;y5;y6;y7;y8];
    %% save results
    temp_Str = num2str(c);
    counter = 0;
    for n = 1:length(temp_Str)
        if (temp_Str(n)~='.')
            counter = counter+1;
            str_c(counter) = temp_Str(n);
        end
    end
    save_Name = ['num_CM_All_Flipping_Total','_N',num2str(gene_N_All(m)),'_c',str_c];
    save (save_Name,'num_CM_All') 
end
%%