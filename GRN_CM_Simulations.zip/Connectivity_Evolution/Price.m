
size_Net = 10000;
sample_Size = 10000;
select_Index = randperm(size_Net,sample_Size);
dx=100;

scatter(c_Pop(select_Index),pop_Robustness(select_Index))
hold on;
mdl2 = GeneralizedLinearModel.fit(c_Pop(select_Index),pop_Robustness(select_Index),'linear','Distribution','normal');
x2 = min(c_Pop):(max(c_Pop)-min(c_Pop))/dx:max(c_Pop);
z2 = mdl2.Coefficients{2,1}.*x2+mdl2.Coefficients{1,1};
plot(x2,z2,'Color',[1 0 0],'LineWidth',3);
hold on;
set(gca,'FontSize',15)
% xlim([min(min(y1(1,:)),min(y1(2,:))),max(max(y1(1,:)),max(y1(2,:)))])
% ylim([min(min(y1(1,:)),min(y1(2,:))),max(max(y1(1,:)),max(y1(2,:)))])
xlim([0 1])
ylim([0 1])
axis square


xlabel('Trait Value [Network Connectivity (c)]','FontSize',20,'FontName','Arial');
ylabel('Reproductive Success [Robustness]','FontSize',20,'FontName','Arial');