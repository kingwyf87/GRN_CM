function pyramid_Founder_Generate()

% clear workspace
clc
clear
close all

% set iteration times for stable development
iter_T = 100;

% set gene networksize
size_Net = 10000;

% set time interval
tau = 10;

% set activation constant
a = 100;

% set number of genes 
gene_N = 10;

% generate initial S
S = randi([0,1],1,gene_N);
S(find(S==0)) = -1;
init_S = ones(1,gene_N);

% collect stable networks 
for n = size_Net:-1:1
    n
    [gene_Net{n}{1},gene_Net{n}{2}] = init_NetDev_Pyramid_Founder(gene_N,init_S,iter_T,a,tau);
end

[c] = mean(cal_Net_Connectivity(gene_Net,size_Net,gene_N));

temp_Str = num2str(c);
counter = 0;
for n = 1:length(temp_Str)
    if (temp_Str(n)~='.')
        counter = counter+1;
        str_c(counter) = temp_Str(n);
    end
end

filename = strcat('gene_Satble_Net_N',num2str(gene_N),'_a',num2str(a),'_Y_Pyramid_Founder','_c',str_c);

save(filename,'gene_Net')