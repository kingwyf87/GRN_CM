function test_Connectivity_Sexual_Non_Adaptive_Evolution_Flipping_N5(max_G,cycle_G,max_T)

%% clear work space
clc

%% load data
load gene_Satble_Net_N5_a100_Y_Founder_c080

%% set parameters
% % set maximum of independent runs
% max_T = 100;
% 
% % set maximum gernation
% max_G = 5000;
% 
% % set flipping gernation for relaxed selction
% cycle_G = 50;
 
% set gene networksize
size_Net = 10000;

% set gene number
gene_N = 5;

% set network connectivity
c = 0.8;

% set activation constant
a = 100;

% set iteration times for stable development
iter_T = 100;

% set time interval
tau = 10;

% set init Pop
gene_Net = gene_Net_N5;

%% Testing
for t = 1:max_T
   
    t
    
    c_Pop_All(:,t) = cal_Connectivity_Sexual_Non_Adaptive_Evolution_Flipping(gene_Net,size_Net,gene_N,max_G,cycle_G,a,iter_T,tau);
    
    %% save results
    temp_Str = num2str(c);
    counter = 0;
    for n = 1:length(temp_Str)
        if (temp_Str(n)~='.')
            counter = counter+1;
            str_c(counter) = temp_Str(n);
        end
    end
    save_Name = ['c_Pop_All_Flipping','_N',num2str(gene_N),'_c',str_c,'_numCycle',num2str(cycle_G)];
    save (save_Name,'c_Pop_All')  
    
end

