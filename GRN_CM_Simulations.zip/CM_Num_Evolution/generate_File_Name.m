function [file_Name] = generate_File_Name(sex,size_Net,max_G,gene_N,c,num_Cycle)

%% save results
temp_Str = num2str(c);
counter = 0;
for n = 1:length(temp_Str)
    if (temp_Str(n)~='.')
        counter = counter+1;
        str_c(counter) = temp_Str(n);
    end
end
file_Name = ['results_',sex,'_Pop',num2str(size_Net),'_G',num2str(max_G),'_N',num2str(gene_N),'_c',str_c,'_numCycle',num2str(num_Cycle)];
