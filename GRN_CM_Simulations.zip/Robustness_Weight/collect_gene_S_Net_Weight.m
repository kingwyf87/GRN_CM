function collect_gene_S_Net_Weight(gene_N,c,a,weight,num_Sample)

load(['gene_Satble_Net_N',num2str(gene_N),'_a',num2str(a),'_K',num2str(c*gene_N)])

% set gene networksize
size_Net = 10000;

% set iteration times for stable development
iter_T = 100;

% set time interval
tau = 10;

w_Net = cell(1,num_Sample);
counter = 0;

while(counter<num_Sample)
        
	% gernerate one random position
    pos_Rand = randi([1,size_Net],1,1);

	% select network
	[init_S] = gene_Net{pos_Rand}{1}; 
	[select_W] = gene_Net{pos_Rand}{2};
        
    % 1st mutation
    [mut_R] = k_Mut_One(select_W,gene_N);
    
    % test stability
    dev_S = net_Dev(mut_R,init_S,iter_T,a);
    if (is_Equilibrium(dev_S,iter_T,gene_N,tau)==0)
        
        % generate random mutation position
        mut_Pos = randi(gene_N,[1,2]);
        while (mut_R(mut_Pos(1),mut_Pos(2))==0)
            mut_Pos = randi(gene_N,[1,2]);
        end

        % 2nd mutation with weight effect
        mut_R(mut_Pos(1),mut_Pos(2)) = mut_R(mut_Pos(1),mut_Pos(2)) + weight; 

        % test stability
        dev_S = net_Dev(mut_R,init_S,iter_T,a);
        if (is_Equilibrium(dev_S,iter_T,gene_N,tau)==1)
            counter = counter +1
            w_Net{counter}{1} = init_S;
            w_Net{counter}{2} = mut_R;
            init_Net{counter}{1} = init_S;
            init_Net{counter}{2} = select_W;
        end
 
    end
        
end

% save resutls
save(['gene_Satble_Net_N',num2str(gene_N),'_Weight_',c_num2str(weight)],'w_Net')

save(['gene_Init_Net_N',num2str(gene_N),'_Weight_',c_num2str(weight)],'init_Net')
