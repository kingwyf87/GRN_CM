function [H] = cal_Pop_Diversity(gene_Net,size_Net,gene_N)

counter = 0;
% find the non-zero items in matrix R
for n = 1:gene_N   
    for m = 1:gene_N
        % get all value at each entry of network
        for i = size_Net:-1:1
            pos_V(i) = gene_Net{i}{2}(n,m);
        end
        % get unique values
        uni_pos_V = unique(pos_V);
        % calcualte frequency of unique values  
        for i = length(uni_pos_V):-1:1
            freq_uni_pos_V(i) = sum(pos_V==uni_pos_V(i))/size_Net;
        end
        % calcualte H for each entry of network
        counter = counter+1;
        H(counter) = 1- sum(freq_uni_pos_V.^2);   
    end
end