function test_Asexual_CM_Non_Adaptive_Evolution_Flipping_N30(max_G,cycle_G,max_T)

%% clear work space
clc

%% load data
load gene_Satble_Net_N30_a100_N_Founder_c076

%% set parameters

% % set maximum of independent runs
% max_T = 10;
% 
% % set maximum gernation
% max_G = 1000;
% 
% % set flipping gernation for relaxed selction
% cycle_G = 50;
 
% set gene networksize
size_Net = 10000;

% set gene number
gene_N = 30;

% set network connectivity
c = 0.76;

% set activation constant
a = 100;

% set iteration times for stable development
iter_T = 100;

% set time interval
tau = 10;

% set init Pop
gene_Net = gene_S_Net_N30;

%% Testing
for t = 1:max_T
   
    t
    
    num_CM_All(:,t) = cal_Num_CM_Asexual_Non_Adaptive_Evolution_Flipping(gene_Net,size_Net,gene_N,max_G+1,cycle_G,a,iter_T,tau);
    
end

%% save results
temp_Str = num2str(c);
counter = 0;
for n = 1:length(temp_Str)
    if (temp_Str(n)~='.')
        counter = counter+1;
        str_c(counter) = temp_Str(n);
    end
end
save_Name = ['num_CM_All_Flipping','_N',num2str(gene_N),'_c',str_c,'cycle_G',num2str(cycle_G)];
save (save_Name,'num_CM_All') 