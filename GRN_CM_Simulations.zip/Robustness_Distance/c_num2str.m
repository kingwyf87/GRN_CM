function [str] = c_num2str(c)

temp_Str = num2str(c);
counter = 0;
for m = 1:length(temp_Str)
    if (temp_Str(m)~='.')
        counter = counter+1;
        str_c(counter) = temp_Str(m);
    end
end
str = str_c;