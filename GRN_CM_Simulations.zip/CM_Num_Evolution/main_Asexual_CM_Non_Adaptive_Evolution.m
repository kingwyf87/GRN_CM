function main_Asexual_CM_Non_Adaptive_Evolution()

%% clear work space
clc
clear

%% load data
load gene_Satble_Net_N10_a100_N_Founder_c075

%% set parameters

% set number of generation cycles
num_Cycle = 50;

% set maximum gernation
max_G = 1000;

% set gernation for each cycle
cycle_G = max_G/num_Cycle;
 
% set gene networksize
size_Net = 10000;

% set gene number
gene_N = 10;

% set network connectivity
c = 0.75;

% set activation constant
a = 100;

% set iteration times for stable development
iter_T = 100;

% set time interval
tau = 10;

% set init Pop
gene_Net = gene_Net_N10;

%% asexual evolution with relaxed selection for stability
for n = 1:num_Cycle
    
    n
    
    pop_Stability = ones(size_Net,1);
    
    for g = 1:cycle_G

        g

        if(g==cycle_G-1)
            flag_Stability = 0;    
        else
            flag_Stability = 1;
        end

        % popluation reproduction
        counter_Pop = 0;
        counter_CM = 0;
        new_Pop = cell(1,size_Net);
        while (counter_Pop<size_Net)

            % gernerate one random position
            pos_Rand = randi([1,size_Net],1,1);
            [select_Net] = gene_Net{pos_Rand};
            [init_S] = select_Net{1};
            [select_W] = select_Net{2};

            % one mutation      
            [mut_W] = k_Mut_One(select_W,gene_N); 

            % test EQ for W
            dev_S = net_Dev(mut_W,init_S,iter_T,a);
            if (is_Equilibrium(dev_S,iter_T,gene_N,tau))               
                stable_Flag = 1;
            else
                stable_Flag = 0;
            end

            % selection for W
            if(flag_Stability==1)
                if (stable_Flag==1)
                    counter_Pop = counter_Pop+1;
                    [new_Pop{counter_Pop}{2}] = mut_W;
                    [new_Pop{counter_Pop}{1}] = init_S;
                end
                if (g==cycle_G)
                    if(pop_Stability(pos_Rand)==0)
                       counter_CM = counter_CM+1; 
                    end
                end
            else
                counter_Pop = counter_Pop+1;
                [new_Pop{counter_Pop}{2}] = mut_W;
                [new_Pop{counter_Pop}{1}] = init_S;
                if (stable_Flag==0)
                    pop_Stability(counter_Pop) = 0;
                end
            end

        end
        
        gene_Net = new_Pop;

    end
    
    % record number of CM in each cycle
    num_CM_All(n) = counter_CM;
    
end

%% save results
temp_Str = num2str(c);
counter = 0;
for n = 1:length(temp_Str)
    if (temp_Str(n)~='.')
        counter = counter+1;
        str_c(counter) = temp_Str(n);
    end
end
save_Name = ['results_Asexual_Pop',num2str(size_Net),'_G',num2str(max_G),'_N',num2str(gene_N),'_c',str_c,'_numCycle',num2str(num_Cycle)];
save (save_Name) 