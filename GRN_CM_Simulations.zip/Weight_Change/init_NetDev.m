% initial gene network development function
function [init_S,init_R] = init_NetDev(gene_N,iter_T,c,a,tau)

% generate initial R  
init_R = rand_R(gene_N,c);

% generate initial S
S = randi([0,1],1,gene_N);
S(find(S==0)) = -1;
init_S = S;

% set the initial S to the developmental S 
dev_S(1,:) = init_S;

% initial gene network development
flag = 1; % set the flag
counter = 1; % set the counter

while(flag==1)
    
    while(counter<=5*2^(2*gene_N) && flag==1)
        
        dev_S = net_Dev(init_R,init_S,iter_T,a);

        if (is_Equilibrium(dev_S,iter_T,gene_N,tau))
            flag = 0;
        else
            % reset the initial R
            init_R = rand_R(gene_N,c);
        end
        counter = counter + 1;
        
    end
    
    if (flag==1)
        % reset the counter
        counter = 1;
        % reset the initial S
        S = randi([0,1],1,gene_N);
        S(find(S==0)) = -1;
        init_S = S;
    end
   
end
