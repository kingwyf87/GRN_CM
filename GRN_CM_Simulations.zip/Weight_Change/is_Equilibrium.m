% gene expression equilibrium test function
function result_E = is_Equilibrium(gene_S,T,N,tau)

aver_S = sum(gene_S(T+1-tau+1:T+1,:))./tau;
temp_Sum = 0;
for t = T+1-tau+1:T+1
   temp_Sum = temp_Sum + calculate_D(gene_S(t,:),aver_S,N);
end
if temp_Sum/tau <= 10^(-4)
   result_E = 1;
else
   result_E = 0;
end

function result_D = calculate_D(S1,S2,N)
result_D = sum((S1-S2).^2)/(4*N);