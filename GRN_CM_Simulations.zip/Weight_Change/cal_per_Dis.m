function [P_CM,P_Non_CM] = cal_per_Dis(R_CM,R_Non_CM,d_max)

for i = 0:d_max    
    if( (  sum(R_CM==i) + sum(R_Non_CM==i)  )~=0    )
        P_CM(i+1) = sum(R_CM==i)/(sum(R_CM==i)+sum(R_Non_CM==i));
        P_Non_CM(i+1) = sum(R_Non_CM==i)/(sum(R_CM==i)+sum(R_Non_CM==i));
    else
        P_CM(i+1) = 0;
        P_Non_CM(i+1) = 0;
    end
end