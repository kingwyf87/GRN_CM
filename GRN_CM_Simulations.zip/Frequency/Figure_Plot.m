function Figure_Plot()

% % % % % % % % % % % % % % % % 
% %       Plot Results      % %
% % % % % % % % % % % % % % % %

% load data
load ('./Data/P_CM_N5_a100')
load ('./Data/P_CM_N10_a100')
load ('./Data/P_CM_N15_a100')
load ('./Data/P_CM_N20_a100')
load ('./Data/P_CM_N30_a100')
load ('./Data/P_CM_N40_a100')

% plot figure
c = 0.2:0.02:1;
plot(c,mean(P_CM_N5,2),'Color',[0.75 0 0.75],'LineWidth',1.5);
hold on
plot(c,mean(P_CM_N10,2),'Color',[0.5 0 0],'LineWidth',1.5);
hold on;
plot(c,mean(P_CM_N15,2),'Color',[0.5 0 0.5],'LineWidth',1.5);
hold on
plot(c,mean(P_CM_N20,2),'Color',[0.168627455830574 0.505882382392883 0.337254911661148],'LineWidth',1.5);
hold on;
plot(c,mean(P_CM_N30,2),'Color',[0 0 1],'LineWidth',1.5);
hold on;
plot(c,mean(P_CM_N40,2),'Color',[1 0 0],'LineWidth',1.5);
hold on;
title('Test for Compensatory Mutation Rates of Random Grenerated Stable Networks','FontSize',25);
ylabel('Frequency of Compensatory Mutation (10,000 Sample Networks)','FontSize',20');
xlabel('Network Connectivity (c)','FontSize',20');
legend1 = legend('N = 05','N = 10','N = 15','N = 20','N = 30','N = 40');
set(legend1,'FontSize',25);
ylim([0 0.2])
xlim([0.2 1])
set(gca,'FontSize',15)
hold off;