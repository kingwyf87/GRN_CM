function test_CM_Frequency_N15()

% clear workspace
clc
clear
close all

% load data
load gene_Satble_Net_N15_a100;

% set gene numbers
gene_N = 15;

% set maximal independent runs
max_T = 100;

% set activation constant
a = 100;

% set iteration times for stable development
iter_T = 100;

% set gene networksize
size_Net = 10000;

% set time interval
tau = 10;

% set network connectivity
c = 0.2:0.02:1;

% Test
for n = 1:length(c)
    
    n
    
    for t = 1:max_T

        % 1st Round Mutation 
        [mut_gene_Net] = net_Mut(gene_Net_N15{n},size_Net,gene_N);

        % Collect Unstable Networks After One Round Mutation
        [unstable_gene_Net] = unstable_NetCollect(mut_gene_Net,size_Net,iter_T,a,gene_N,tau);

        % 2nd Round Mutation 
        [mut_gene_Net] = net_Mut(unstable_gene_Net,length(unstable_gene_Net),gene_N); 

        % Calculate CM Frequency
        [P_CM_N15(n,t)] = cal_P_stable(mut_gene_Net,length(mut_gene_Net),iter_T,a,gene_N,tau,size_Net);
                         
    end
    
end


filename = strcat('P_CM_N15_a',num2str(a));
save(filename,'P_CM_N15')
