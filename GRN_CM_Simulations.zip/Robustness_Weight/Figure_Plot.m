function Figure_Plot()

% % % % % % % % % % % % % % % % 
% %       Plot Results      % %
% % % % % % % % % % % % % % % %
%%
clear
clc
%%
gene_N = 5;
K = 2;
c = K/gene_N;
W = [-5 -4 -3 -2 -1 -0.5 -0.1 0.1 0.5 1 2 3 4 5];
T = 100;
size_Net = 10000;
%%
net_Robustness_Weight = [];
net_Init_Robustness_Weight = [];
for n = 1:length(W)
   load(['net_Robustness_N',num2str(gene_N),'_Weight_',c_num2str(W(n))])
   net_Robustness_Weight = [net_Robustness_Weight;net_Robustness];
	load(['net_Init_Robustness_N',num2str(gene_N),'_Weight_',c_num2str(W(n))])
   net_Init_Robustness_Weight = [net_Init_Robustness_Weight;net_Robustness];
end
save(['net_Robustness_Weight_N',num2str(gene_N),'_K',num2str(K)],'net_Robustness_Weight')
save(['net_Init_Robustness_Weight_N',num2str(gene_N),'_K',num2str(K)],'net_Init_Robustness_Weight')
errorbar(W,mean(net_Robustness_Weight,2),1.96*std(net_Robustness_Weight,0,2)/sqrt(T),'Color',[0 0 1],'LineWidth',1.5,'MarkerSize',20,'Marker','.','LineStyle','none')
hold on;
errorbar(W,mean(net_Init_Robustness_Weight,2),1.96*std(net_Init_Robustness_Weight,0,2)/sqrt(T),'Color',[1 0 0],'LineWidth',1.5,'MarkerSize',20,'Marker','.','LineStyle','none')
hold off;
title({'Test for Robustness of Stable Networks with Effect Size of Gene Regulation' ,strcat(' [Pop=',num2str(size_Net),', N=',num2str(gene_N),', c=',num2str(c),']')},...
    'FontSize',30,...
    'FontName','Arial');
xlabel(['Shift in Gene Regulation (Fold Change)'],...
    'FontSize',25,...
    'FontName','Arial');
ylabel(['Mean Robustness'],...
    'FontSize',25,...
    'FontName','Arial');
text1 = ['N',num2str(gene_N),', c=',num2str(c),'(Initial)'];
text2 = ['N',num2str(gene_N),', c=',num2str(c),'(Compensated)'];
legend1 = legend(text1,text2);
% ylim([0.7,0.85])
set(legend1,'Location','SouthEast','FontSize',25,'FontName','Arial');
set(gca,'XTick',[-5:5],'FontName','Arial','FontSize',20)

% % % % % % % % % % % % % % %
% Plot Change in Robustness %
% % % % % % % % % % % % % % %
%%
load net_Robustness_Weight_N5_K2
R_N5_CM = net_Robustness_Weight;
load net_Robustness_Weight_N20_K4
R_N20_CM = net_Robustness_Weight;
load net_Robustness_Weight_N40_K6
R_N40_CM = net_Robustness_Weight;
%%
load net_Neutral_Weight_Robustness_N5_K2
R_N5_Neutral = net_Neutral_Weight_Robustness;
load net_Neutral_Weight_Robustness_N20_K4
R_N20_Neutral = net_Neutral_Weight_Robustness;
load net_Neutral_Weight_Robustness_N40_K6
R_N40_Neutral = net_Neutral_Weight_Robustness;
%%
for n = 1:100
    R_N5_CM_Change(:,n) = (R_N5_CM(:,n)-min(R_N5_CM(:,n)))./min(R_N5_CM(:,n))*100;
end
for n = 1:100
    R_N20_CM_Change(:,n) = (R_N20_CM(:,n)-min(R_N20_CM(:,n)))./min(R_N20_CM(:,n))*100;
end
for n = 1:100
    R_N40_CM_Change(:,n) = (R_N40_CM(:,n)-min(R_N40_CM(:,n)))./min(R_N40_CM(:,n))*100;
end
for n = 1:100
    R_N5_Neutral_Change(:,n) = (R_N5_Neutral(:,n)-min(R_N5_Neutral(:,n)))./min(R_N5_Neutral(:,n))*100;
end
for n = 1:100
    R_N20_Neutral_Change(:,n) = (R_N20_Neutral(:,n)-min(R_N20_Neutral(:,n)))./min(R_N20_Neutral(:,n))*100;
end
for n = 1:100
    R_N40_Neutral_Change(:,n) = (R_N40_Neutral(:,n)-min(R_N40_Neutral(:,n)))./min(R_N40_Neutral(:,n))*100;
end
% R_N5_CM_Change = (R_N5_CM-min(R_N5_CM(:)))./min(R_N5_CM(:))*100;
% R_N20_CM_Change = (R_N20_CM-min(R_N20_CM(:)))./min(R_N20_CM(:))*100;
% R_N40_CM_Change = (R_N40_CM-min(R_N40_CM(:)))./min(R_N40_CM(:))*100;
% R_N5_Neutral_Change = (R_N5_Neutral-min(R_N5_Neutral(:)))./min(R_N5_Neutral(:))*100;
% R_N20_Neutral_Change = (R_N20_Neutral-min(R_N20_Neutral(:)))./min(R_N20_Neutral(:))*100;
% R_N40_Neutral_Change = (R_N40_Neutral-min(R_N40_Neutral(:)))./min(R_N40_Neutral(:))*100;
%%
save R_CM_Change_Weight_N5_K2 R_N5_CM_Change
save R_CM_Change_Weight_N20_K4 R_N20_CM_Change
save R_CM_Change_Weight_N40_K6 R_N40_CM_Change
save R_Neutral_Change_Weight_N5_K2 R_N5_Neutral_Change
save R_Neutral_Change_Weight_N20_K4 R_N20_Neutral_Change
save R_Neutral_Change_Weight_N40_K6 R_N40_Neutral_Change
%%
y1 = R_N5_Neutral_Change;
y2 = R_N5_CM_Change;
gene_N = 5;
K = 2;
%%
y1 = R_N20_Neutral_Change;
y2 = R_N20_CM_Change;
gene_N = 20;
K = 4;
%%
y1 = R_N40_Neutral_Change;
y2 = R_N40_CM_Change;
gene_N = 40;
K = 6;
%%
c = K/gene_N;
W = [-5 -4 -3 -2 -1 -0.5 -0.1 0.1 0.5 1 2 3 4 5];
T = 100;
size_Net = 10000;
%%
errorbar(W,mean(y1,2),1.96*std(y1,0,2)/sqrt(T),'Color',[0 0 1],'LineWidth',1.5,'MarkerSize',20,'Marker','.','LineStyle','none')
hold on;
errorbar(W,mean(y2,2),1.96*std(y2,0,2)/sqrt(T),'Color',[1 0 0],'LineWidth',1.5,'MarkerSize',20,'Marker','.','LineStyle','none')
hold off;
title({'Test for Robustness of Stable Networks with Effect Size of Gene Regulation' ,strcat(' [Pop=',num2str(size_Net),', N=',num2str(gene_N),', c=',num2str(c),']')},...
    'FontSize',30,...
    'FontName','Arial');
xlabel(['Shift in Gene Regulation (Fold Change)'],...
    'FontSize',25,...
    'FontName','Arial');
ylabel(['Changed Robustness (%)'],...
    'FontSize',25,...
    'FontName','Arial');
text1 = ['N',num2str(gene_N),', c=',num2str(c),'(Neutral)'];
text2 = ['N',num2str(gene_N),', c=',num2str(c),'(Compensatory)'];
legend1 = legend(text1,text2);
set(legend1,'Location','SouthEast','FontSize',25,'FontName','Arial');
xlim([-5.1,5.1])
set(gca,'XTick',[-5:1:5],'FontName','Arial','FontSize',20)