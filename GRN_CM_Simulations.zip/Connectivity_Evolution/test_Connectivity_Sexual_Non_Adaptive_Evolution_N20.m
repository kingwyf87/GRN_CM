function test_Connectivity_Sexual_Non_Adaptive_Evolution_N20(max_G,num_Cycle,max_T)

%% clear work space
clc

%% load data
load gene_Satble_Net_N20_a100_Y_Founder_c030

%% set parameters

% % set maximum of independent runs
% max_T = 100;
% 
% % set number of generation cycles
% num_Cycle = 50;
% 
% % set maximum gernation
% max_G = 1000;

% set gernation for each cycle
cycle_G = max_G/num_Cycle;
 
% set gene networksize
size_Net = 10000;

% set gene number
gene_N = 20;

% set network connectivity
c = 0.25;

% set activation constant
a = 100;

% set iteration times for stable development
iter_T = 100;

% set time interval
tau = 10;

% set init Pop
gene_Net = gene_Net_N20;

%% Testing
for t = 1:max_T
   
    t
    
    c_Pop_All(:,t) = cal_Connectivity_Sexual_Non_Adaptive_Evolution(gene_Net,size_Net,gene_N,num_Cycle,cycle_G,a,iter_T,tau);
    
end

%% save results
temp_Str = num2str(c);
counter = 0;
for n = 1:length(temp_Str)
    if (temp_Str(n)~='.')
        counter = counter+1;
        str_c(counter) = temp_Str(n);
    end
end
save_Name = ['c_Pop_All','_N',num2str(gene_N),'_c',str_c,'_numCycle',num2str(num_Cycle)];
save (save_Name,'c_Pop_All') 