function test_Connectivity_Evolution_Flipping_Pyramid(gene_N,c,max_G,cycle_G,max_T)

%% clear work space
clc

%% load data
load(['gene_Satble_Net_N',num2str(gene_N),'_a100_Y_Pyramid_Founder_c',c_num2str(c)])

%% set parameters
% % set maximum of independent runs
% max_T = 100;
% 
% % set maximum gernation
% max_G = 5000;
% 
% % set flipping gernation for relaxed selction
% cycle_G = 50;
%  
% % set network connectivity
% c = 0.8;
% 
% % set gene number
% gene_N = 5;

% set gene networksize
size_Net = 10000;

% set activation constant
a = 100;

% set iteration times for stable development
iter_T = 100;

% set time interval
tau = 10;

%% Testing
for t = 1:max_T
   
    t
    
    [c_Pop_All(:,t),c_gene_Net{t}] = cal_Connectivity_Sexual_Non_Adaptive_Evolution_Flipping_Pyramid(gene_Net,size_Net,gene_N,max_G+1,cycle_G,a,iter_T,tau);
    
    %% save results
    save_Name = ['c_Pop_All_Flipping_Pyramid_Founder','_N',num2str(gene_N),'_c',c_num2str(c),'_numCycle',num2str(cycle_G)];
    save (save_Name,'c_Pop_All')
	save_Name = ['pop_All_Flipping_Pyramid_Founder','_N',num2str(gene_N),'_c',c_num2str(c),'_numCycle',num2str(cycle_G)];
    save (save_Name,'c_gene_Net') 
    
end

