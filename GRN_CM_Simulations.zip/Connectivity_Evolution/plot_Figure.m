function plot_Figure()

%% clear workspace
clear
close all
clc
%% set parameters
num_Cycle_All = [50 25 10 5 1];
gene_N = 5;
c = 0.25;
sex = 'Asexual';
max_G = 1000;
size_Net = 10000;
%% load data
load(generate_File_Name(sex,size_Net,max_G,gene_N,c,num_Cycle_All(1)))
y1 = sum(num_CM_All)/gene_N/num_Cycle_All(1)/20;
load(generate_File_Name(sex,size_Net,max_G,gene_N,c,num_Cycle_All(2)))
y2 = sum(num_CM_All)/gene_N/num_Cycle_All(2)/40;
load(generate_File_Name(sex,size_Net,max_G,gene_N,c,num_Cycle_All(3)))
y3 = sum(num_CM_All)/gene_N/num_Cycle_All(3)/100;
load(generate_File_Name(sex,size_Net,max_G,gene_N,c,num_Cycle_All(4)))
y4 = sum(num_CM_All)/gene_N/num_Cycle_All(4)/200;
load(generate_File_Name(sex,size_Net,max_G,gene_N,c,num_Cycle_All(5)))
y5 = sum(num_CM_All)/gene_N/num_Cycle_All(5)/1000;
%%
num_Cycle_All = [50 25 10 5 1];
gene_N = 10;
c = 0.75;
sex = 'Sexual';
max_G = 1000;
size_Net = 10000;
%% load data
load(generate_File_Name(sex,size_Net,max_G,gene_N,c,num_Cycle_All(1)))
y11 = sum(num_CM_All)/gene_N/num_Cycle_All(1)/20;
load(generate_File_Name(sex,size_Net,max_G,gene_N,c,num_Cycle_All(2)))
y22 = sum(num_CM_All)/gene_N/num_Cycle_All(2)/40;
load(generate_File_Name(sex,size_Net,max_G,gene_N,c,num_Cycle_All(3)))
y33 = sum(num_CM_All)/gene_N/num_Cycle_All(3)/100;
load(generate_File_Name(sex,size_Net,max_G,gene_N,c,num_Cycle_All(4)))
y44 = sum(num_CM_All)/gene_N/num_Cycle_All(4)/200;
load(generate_File_Name(sex,size_Net,max_G,gene_N,c,num_Cycle_All(5)))
y55 = sum(num_CM_All)/gene_N/num_Cycle_All(5)/1000;
%% plot results
figure;
plot((max_G-num_Cycle_All)/max_G,[y1 y2 y3 y4 y5],'Color',[0 0 1],'LineWidth',1.5);
hold on;
plot((max_G-num_Cycle_All)/max_G,[y11 y22 y33 y44 y55],'Color',[1 0 0],'LineWidth',1.5);
hold off;
title({'Test for Number of Compensatory Mutations Under Different Stability Selection Pressure' ,strcat(' [Pop=',num2str(size_Net),', N=',num2str(gene_N),', c=',num2str(c),', G=',num2str(max_G),']')},...
    'FontSize',30,...
    'FontName','Arial');
xlabel('Precentage of Stability Selection During Non-Adaptive Evolution',...
    'FontSize',25,...
    'FontName','Arial');
ylabel(['Number of Compensatory Mutations',sprintf('\n'),'(per locus, per generation)'],...
    'FontSize',25,...
    'FontName','Arial');
text1 = ['N = ' num2str(gene_N),' c = ',num2str(c),'(Asexual)'];
text2 = ['N = ' num2str(gene_N),' c = ',num2str(c),'(Sexual)'];
% legend1 = legend(text1);
legend1 = legend(text1,text2);
set(legend1,'Location','NorthEast','FontSize',25,'FontName','Arial');
set(gca,'FontSize',20)
xlim([0.95 1])
% ylim([0,0.2]);


%% Reshap Data (No Flippling)
clear
close all
clc
%% set parameters
num_Cycle_All = [50 25 10 5 1];
gene_N_All = [5 10 15 20 30 40];
c = 0.25;
max_G = 1000;
size_Net = 10000;
for m = 1:length(num_Cycle_All)
    
    %% load data
    load(generate_File_Name(gene_N_All(1),c,num_Cycle_All(m)))
    y1 = mean(c_Pop_All,2);
    std1 = std(c_Pop_All,1,2);
    load(generate_File_Name(gene_N_All(2),c,num_Cycle_All(m)))
    y2 = mean(c_Pop_All,2);
    std2 = std(c_Pop_All,1,2);
    load(generate_File_Name(gene_N_All(3),c,num_Cycle_All(m)))
    y3 = mean(c_Pop_All,2);
    std3 = std(c_Pop_All,1,2);
    load(generate_File_Name(gene_N_All(4),c,num_Cycle_All(m)))
    y4 = mean(c_Pop_All,2);
    std4 = std(c_Pop_All,1,2);
    load(generate_File_Name(gene_N_All(5),c,num_Cycle_All(m)))
    y5 = mean(c_Pop_All,2);
    std5 = std(c_Pop_All,1,2);
    load(generate_File_Name(gene_N_All(6),c,num_Cycle_All(m)))
    y6 = mean(c_Pop_All,2);
    std6 = std(c_Pop_All,1,2);
    %%
    figure;
    plot(1:num_Cycle_All(m),y1,'Color',[0.75 0 0.75],'LineWidth',1.5);
    hold on
    plot(1:num_Cycle_All(m),y2,'Color',[0.5 0 0],'LineWidth',1.5);
    hold on;
    plot(1:num_Cycle_All(m),y3,'Color',[0.5 0 0.5],'LineWidth',1.5);
    hold on;
    plot(1:num_Cycle_All(m),y4,'Color',[0.168627455830574 0.505882382392883 0.337254911661148],'LineWidth',1.5);
    hold on;
    plot(1:num_Cycle_All(m),y5,'Color',[0 0 1],'LineWidth',1.5);
    hold on;
    plot(1:num_Cycle_All(m),y6,'Color',[1 0 0],'LineWidth',1.5);
    hold off;    
    %%
    title({'Test for Network Connectivity Under Different Stability Selection Pressure' ,strcat(' [Pop=',num2str(size_Net),', c=',num2str(c),', G=',num2str(max_G),', numCycle=',num2str(num_Cycle_All(m)),']')},...
            'FontSize',30,...
            'FontName','Arial');
    xlabel(['Epochs (Generations/',num2str(max_G/num_Cycle_All(m)),')'],...
        'FontSize',25,...
        'FontName','Arial');
    ylabel(['Mean Network Connectivity',sprintf('\n')],...
        'FontSize',25,...
        'FontName','Arial');
    text1 = ['N = ' num2str(gene_N_All(1))];
    text2 = ['N = ' num2str(gene_N_All(2))];
    text3 = ['N = ' num2str(gene_N_All(3))];
    text4 = ['N = ' num2str(gene_N_All(4))];
    text5 = ['N = ' num2str(gene_N_All(5))];
    text6 = ['N = ' num2str(gene_N_All(6))];
    legend1 = legend(text1,text2,text3,text4,text5,text6);
    set(legend1,'Location','NorthEast','FontSize',25,'FontName','Arial');
    set(gca,'FontSize',20,'FontName','Arial')        
end


%% Reshap Data
clear
close all
clc
%% set parameters
num_Cycle_All = [1 2 5 10 25 50];
gene_N_All = [5 10 15  20 30 40 50 100 100];
c = [0.8 0.6 0.4 0.3 0.2 0.15 0.05 0.05 0.024];
max_G = 5000;
for n=1:length(gene_N_All)
    %% load data
    load(generate_File_Name_Flipping(gene_N_All(n),c(n),num_Cycle_All(1)))
    y1 = mean(c_Pop_All,2)';
    std1 = std(c_Pop_All,1,2)';
    load(generate_File_Name_Flipping(gene_N_All(n),c(n),num_Cycle_All(2)))
    y2 = mean(c_Pop_All,2)';
    std2 = std(c_Pop_All,1,2)';
    load(generate_File_Name_Flipping(gene_N_All(n),c(n),num_Cycle_All(3)))
    y3 = mean(c_Pop_All,2)';
    std3 = std(c_Pop_All,1,2)';
    load(generate_File_Name_Flipping(gene_N_All(n),c(n),num_Cycle_All(4)))
    y4 = mean(c_Pop_All,2)';
    std4 = std(c_Pop_All,1,2)';
    load(generate_File_Name_Flipping(gene_N_All(n),c(n),num_Cycle_All(5)))
    y5 = mean(c_Pop_All,2)';
    std5 = std(c_Pop_All,1,2)';
    load(generate_File_Name_Flipping(gene_N_All(n),c(n),num_Cycle_All(6)))
    y6 = mean(c_Pop_All,2)';
    std6 = std(c_Pop_All,1,2)';
    %%
    num_CM_All_Mean = [y1;y2;y3;y4;y5;y6];
    num_CM_All_Std= [std1;std2;std3;std4;std5;std6];
    %% save results
    temp_Str = num2str(c(n));
    counter = 0;
    for m = 1:length(temp_Str)
        if (temp_Str(m)~='.')
            counter = counter+1;
            str_c(counter) = temp_Str(m);
        end
    end
    save_Name = ['num_CM_All_Mean','_N',num2str(gene_N_All(n)),'_c',str_c,'_max_G',num2str(max_G)];
    save (save_Name,'num_CM_All_Mean') 
    save_Name = ['num_CM_All_Std','_N',num2str(gene_N_All(n)),'_c',str_c,'_max_G',num2str(max_G)];
    save (save_Name,'num_CM_All_Std')
end


%% No Error Bar
clear
clc
num_Cycle_All = [1 2 5 10 25 50];
gene_N_All = [5 10 15  20 30 40 50 100 100];
c = [0.8 0.6 0.4 0.3 0.2 0.15 0.05 0.05 0.024];
max_G = 5000;
size_Net = 10000;
record_G = 50;
%% load data
load (['num_CM_All_Mean','_N',num2str(gene_N_All(1)),'_c',c_num2str(c(1)),'_max_G',num2str(max_G)])
y{1} = num_CM_All_Mean;
load (['num_CM_All_Mean','_N',num2str(gene_N_All(2)),'_c',c_num2str(c(2)),'_max_G',num2str(max_G)])
y{2} = num_CM_All_Mean;
load (['num_CM_All_Mean','_N',num2str(gene_N_All(3)),'_c',c_num2str(c(3)),'_max_G',num2str(max_G)])
y{3} = num_CM_All_Mean;
load (['num_CM_All_Mean','_N',num2str(gene_N_All(4)),'_c',c_num2str(c(4)),'_max_G',num2str(max_G)])
y{4} = num_CM_All_Mean;
load (['num_CM_All_Mean','_N',num2str(gene_N_All(5)),'_c',c_num2str(c(5)),'_max_G',num2str(max_G)])
y{5} = num_CM_All_Mean;
load (['num_CM_All_Mean','_N',num2str(gene_N_All(6)),'_c',c_num2str(c(6)),'_max_G',num2str(max_G)])
y{6} = num_CM_All_Mean;
load (['num_CM_All_Mean','_N',num2str(gene_N_All(7)),'_c',c_num2str(c(7)),'_max_G',num2str(max_G)])
y{7} = num_CM_All_Mean;
load (['num_CM_All_Mean','_N',num2str(gene_N_All(8)),'_c',c_num2str(c(8)),'_max_G',num2str(max_G)])
y{8} = num_CM_All_Mean;
load (['num_CM_All_Mean','_N',num2str(gene_N_All(9)),'_c',c_num2str(c(9)),'_max_G',num2str(max_G)])
y{9} = num_CM_All_Mean;
%% plot results
for n=1:length(gene_N_All)  
    figure;
    plot(1:max_G/record_G,y{n}(1,:),'Color',[0.75 0 0.75],'LineWidth',1.5);
    hold on
    plot(1:max_G/record_G,y{n}(2,:),'Color',[0.5 0 0],'LineWidth',1.5);
    hold on;
    plot(1:max_G/record_G,y{n}(3,:),'Color',[0.5 0 0.5],'LineWidth',1.5);
    hold on;
    plot(1:max_G/record_G,y{n}(4,:),'Color',[0.168627455830574 0.505882382392883 0.337254911661148],'LineWidth',1.5);
    hold on;
    plot(1:max_G/record_G,y{n}(5,:),'Color',[0 0 1],'LineWidth',1.5);
    hold on;
    plot(1:max_G/record_G,y{n}(6,:),'Color',[1 0 0],'LineWidth',1.5);
    hold off;
    title({'Test for Network Connectivity Under Different Stability Selection Pressure' ,strcat(' [Pop=',num2str(size_Net),', N=',num2str(gene_N_All(n)),', c=',num2str(c(n)),', G=',num2str(max_G),']')},...
        'FontSize',30,...
        'FontName','Arial');
    xlabel(['Epochs (Generations/',num2str(record_G),')'],...
        'FontSize',25,...
        'FontName','Arial');
    ylabel(['Mean Network Connectivity',sprintf('\n')],...
        'FontSize',25,...
        'FontName','Arial');
    text1 = ['No Relaxed Selection'];
    text2 = ['Relaxed Selection Interval = ' num2str(num_Cycle_All(2))];
    text3 = ['Relaxed Selection Interval = ' num2str(num_Cycle_All(3))];
    text4 = ['Relaxed Selection Interval = ' num2str(num_Cycle_All(4))];
    text5 = ['Relaxed Selection Interval = ' num2str(num_Cycle_All(5))];
    text6 = ['Relaxed Selection Interval = ' num2str(num_Cycle_All(6))];
    legend1 = legend(text1,text2,text3,text4,text5,text6);
    set(legend1,'Location','NorthEast','FontSize',15,'FontName','Arial');
    set(gca,'FontSize',20)
    xlim([0 100])
end



%% Error Bar
clear
clc
num_Cycle_All = [1 2 5 10 25 50];
gene_N_All = [5 10 15  20 30 40 50 100 100];
c = [0.8 0.6 0.4 0.3 0.2 0.15 0.05 0.05 0.024];
max_G = 5000;
size_Net = 10000;
record_G = 50;
max_T = 100;
%% load data
load (['num_CM_All_Mean','_N',num2str(gene_N_All(1)),'_c',c_num2str(c(1)),'_max_G',num2str(max_G)])
load (['num_CM_All_Std','_N',num2str(gene_N_All(1)),'_c',c_num2str(c(1)),'_max_G',num2str(max_G)])
y{1} = num_CM_All_Mean;
std{1} = num_CM_All_Std;
load (['num_CM_All_Mean','_N',num2str(gene_N_All(2)),'_c',c_num2str(c(2)),'_max_G',num2str(max_G)])
load (['num_CM_All_Std','_N',num2str(gene_N_All(2)),'_c',c_num2str(c(2)),'_max_G',num2str(max_G)])
y{2} = num_CM_All_Mean;
std{2} = num_CM_All_Std;
load (['num_CM_All_Mean','_N',num2str(gene_N_All(3)),'_c',c_num2str(c(3)),'_max_G',num2str(max_G)])
load (['num_CM_All_Std','_N',num2str(gene_N_All(3)),'_c',c_num2str(c(3)),'_max_G',num2str(max_G)])
y{3} = num_CM_All_Mean;
std{3} = num_CM_All_Std;
load (['num_CM_All_Mean','_N',num2str(gene_N_All(4)),'_c',c_num2str(c(4)),'_max_G',num2str(max_G)])
load (['num_CM_All_Std','_N',num2str(gene_N_All(4)),'_c',c_num2str(c(4)),'_max_G',num2str(max_G)])
y{4} = num_CM_All_Mean;
std{4} = num_CM_All_Std;
load (['num_CM_All_Mean','_N',num2str(gene_N_All(5)),'_c',c_num2str(c(5)),'_max_G',num2str(max_G)])
load (['num_CM_All_Std','_N',num2str(gene_N_All(5)),'_c',c_num2str(c(5)),'_max_G',num2str(max_G)])
y{5} = num_CM_All_Mean;
std{5} = num_CM_All_Std;
load (['num_CM_All_Mean','_N',num2str(gene_N_All(6)),'_c',c_num2str(c(6)),'_max_G',num2str(max_G)])
load (['num_CM_All_Std','_N',num2str(gene_N_All(6)),'_c',c_num2str(c(6)),'_max_G',num2str(max_G)])
y{6} = num_CM_All_Mean;
std{6} = num_CM_All_Std;
%% plot results
for n=1:length(gene_N_All)  
    figure;
    errorbar(1:max_G/record_G,y{n}(1,:),std{n}(1,:)*1.96./sqrt(max_T),'Color',[0.75 0 0.75],'LineWidth',1.5);
    hold on
    errorbar(1:max_G/record_G,y{n}(2,:),std{n}(1,:)*1.96./sqrt(max_T),'Color',[0.5 0 0],'LineWidth',1.5);
    hold on;
    errorbar(1:max_G/record_G,y{n}(3,:),std{n}(1,:)*1.96./sqrt(max_T),'Color',[0.5 0 0.5],'LineWidth',1.5);
    hold on;
    errorbar(1:max_G/record_G,y{n}(4,:),std{n}(1,:)*1.96./sqrt(max_T),'Color',[0.168627455830574 0.505882382392883 0.337254911661148],'LineWidth',1.5);
    hold on;
    errorbar(1:max_G/record_G,y{n}(5,:),std{n}(1,:)*1.96./sqrt(max_T),'Color',[0 0 1],'LineWidth',1.5);
    hold on;
    errorbar(1:max_G/record_G,y{n}(6,:),std{n}(1,:)*1.96./sqrt(max_T),'Color',[1 0 0],'LineWidth',1.5);
    hold off;
    title({'Test for Network Connectivity Under Different Stability Selection Pressure' ,strcat(' [Pop=',num2str(size_Net),', N=',num2str(gene_N_All(n)),', c=',num2str(c(n)),', G=',num2str(max_G),']')},...
        'FontSize',30,...
        'FontName','Arial');
    xlabel(['Epochs (Generations/',num2str(record_G),')'],...
        'FontSize',25,...
        'FontName','Arial');
    ylabel(['Mean Network Connectivity',sprintf('\n')],...
        'FontSize',25,...
        'FontName','Arial');
    text1 = ['No Relaxed Selection'];
    text2 = ['Relaxed Selection Interval = ' num2str(num_Cycle_All(2))];
    text3 = ['Relaxed Selection Interval = ' num2str(num_Cycle_All(3))];
    text4 = ['Relaxed Selection Interval = ' num2str(num_Cycle_All(4))];
    text5 = ['Relaxed Selection Interval = ' num2str(num_Cycle_All(5))];
    text6 = ['Relaxed Selection Interval = ' num2str(num_Cycle_All(6))];
    legend1 = legend(text1,text2,text3,text4,text5,text6);
    set(legend1,'Location','NorthEast','FontSize',15,'FontName','Arial');
    set(gca,'FontSize',20)
    xlim([0 100])
end

%% Reshap Data
clear
close all
clc
%% set parameters
num_Cycle_All = [1 2 5 10 25 50 100 200 500];
gene_N = 40;
c = 0.15;
max_G = 5000;
%%
temp_Str = num2str(c);
counter = 0;
for m = 1:length(temp_Str)
    if (temp_Str(m)~='.')
        counter = counter+1;
        str_c(counter) = temp_Str(m);
    end
end
%% load data
load(generate_File_Name_Flipping(gene_N,c,num_Cycle_All(1)))
save_Name = ['connectivity_Evolution','_N',num2str(gene_N),'_c',str_c,'_max_G',num2str(max_G),'_numCycle',num2str(num_Cycle_All(1))];
save (save_Name,'c_Pop_All')
load(generate_File_Name_Flipping(gene_N,c,num_Cycle_All(2)))
save_Name = ['connectivity_Evolution','_N',num2str(gene_N),'_c',str_c,'_max_G',num2str(max_G),'_numCycle',num2str(num_Cycle_All(2))];
save (save_Name,'c_Pop_All')
load(generate_File_Name_Flipping(gene_N,c,num_Cycle_All(3)))
save_Name = ['connectivity_Evolution','_N',num2str(gene_N),'_c',str_c,'_max_G',num2str(max_G),'_numCycle',num2str(num_Cycle_All(3))];
save (save_Name,'c_Pop_All')
load(generate_File_Name_Flipping(gene_N,c,num_Cycle_All(4)))
save_Name = ['connectivity_Evolution','_N',num2str(gene_N),'_c',str_c,'_max_G',num2str(max_G),'_numCycle',num2str(num_Cycle_All(4))];
save (save_Name,'c_Pop_All')
load(generate_File_Name_Flipping(gene_N,c,num_Cycle_All(5)))
save_Name = ['connectivity_Evolution','_N',num2str(gene_N),'_c',str_c,'_max_G',num2str(max_G),'_numCycle',num2str(num_Cycle_All(5))];
save (save_Name,'c_Pop_All')
load(generate_File_Name_Flipping(gene_N,c,num_Cycle_All(6)))
save_Name = ['connectivity_Evolution','_N',num2str(gene_N),'_c',str_c,'_max_G',num2str(max_G),'_numCycle',num2str(num_Cycle_All(6))];
save (save_Name,'c_Pop_All')
load(generate_File_Name_Flipping(gene_N,c,num_Cycle_All(7)))
save_Name = ['connectivity_Evolution','_N',num2str(gene_N),'_c',str_c,'_max_G',num2str(max_G),'_numCycle',num2str(num_Cycle_All(7))];
save (save_Name,'c_Pop_All')
load(generate_File_Name_Flipping(gene_N,c,num_Cycle_All(8)))
save_Name = ['connectivity_Evolution','_N',num2str(gene_N),'_c',str_c,'_max_G',num2str(max_G),'_numCycle',num2str(num_Cycle_All(8))];
save (save_Name,'c_Pop_All')
load(generate_File_Name_Flipping(gene_N,c,num_Cycle_All(9)))
save_Name = ['connectivity_Evolution','_N',num2str(gene_N),'_c',str_c,'_max_G',num2str(max_G),'_numCycle',num2str(num_Cycle_All(9))];
save (save_Name,'c_Pop_All')



%% Reshap Data (Ring)
clear
close all
clc
%% set parameters
num_Cycle_All = [1 2 5 10 25 50];
gene_N_All = [10 20];
c = [0.15 0.08];
max_G = 5000;
for n=1:length(gene_N_All)
    %% load data
    load(generate_File_Name_Flipping_Ring(gene_N_All(n),c(n),num_Cycle_All(1)))
    y1 = mean(c_Pop_All,2)';
    std1 = std(c_Pop_All,1,2)';
    load(generate_File_Name_Flipping_Ring(gene_N_All(n),c(n),num_Cycle_All(2)))
    y2 = mean(c_Pop_All,2)';
    std2 = std(c_Pop_All,1,2)';
    load(generate_File_Name_Flipping_Ring(gene_N_All(n),c(n),num_Cycle_All(3)))
    y3 = mean(c_Pop_All,2)';
    std3 = std(c_Pop_All,1,2)';
    load(generate_File_Name_Flipping_Ring(gene_N_All(n),c(n),num_Cycle_All(4)))
    y4 = mean(c_Pop_All,2)';
    std4 = std(c_Pop_All,1,2)';
    load(generate_File_Name_Flipping_Ring(gene_N_All(n),c(n),num_Cycle_All(5)))
    y5 = mean(c_Pop_All,2)';
    std5 = std(c_Pop_All,1,2)';
    load(generate_File_Name_Flipping_Ring(gene_N_All(n),c(n),num_Cycle_All(6)))
    y6 = mean(c_Pop_All,2)';
    std6 = std(c_Pop_All,1,2)';
    %%
    c_All_Mean = [y1;y2;y3;y4;y5;y6];
    c_All_Std = [std1;std2;std3;std4;std5;std6];
    %% save results
    temp_Str = num2str(c(n));
    counter = 0;
    for m = 1:length(temp_Str)
        if (temp_Str(m)~='.')
            counter = counter+1;
            str_c(counter) = temp_Str(m);
        end
    end
    save_Name = ['c_All_Mean_Ring','_N',num2str(gene_N_All(n)),'_c',str_c,'_max_G',num2str(max_G)];
    save (save_Name,'c_All_Mean') 
    save_Name = ['c_All_Std_Ring','_N',num2str(gene_N_All(n)),'_c',str_c,'_max_G',num2str(max_G)];
    save (save_Name,'c_All_Std')
end


%% No Error Bar (Ring)
clear
clc
num_Cycle_All = [1 2 5 10 25 50];
gene_N_All = [10 20];
c = [0.15 0.08];
max_G = 5000;
size_Net = 10000;
record_G = 50;
%% load data
load (['c_All_Mean_Ring','_N',num2str(gene_N_All(1)),'_c',c_num2str(c(1)),'_max_G',num2str(max_G)])
y{1} = c_All_Mean;
load (['c_All_Mean_Ring','_N',num2str(gene_N_All(2)),'_c',c_num2str(c(2)),'_max_G',num2str(max_G)])
y{2} = c_All_Mean;
load (['c_All_Mean_Ring','_N',num2str(gene_N_All(3)),'_c',c_num2str(c(3)),'_max_G',num2str(max_G)])
y{3} = c_All_Mean;
load (['c_All_Mean_Ring','_N',num2str(gene_N_All(4)),'_c',c_num2str(c(4)),'_max_G',num2str(max_G)])
y{4} = c_All_Mean;
load (['c_All_Mean_Ring','_N',num2str(gene_N_All(5)),'_c',c_num2str(c(5)),'_max_G',num2str(max_G)])
y{5} = c_All_Mean;
load (['c_All_Mean_Ring','_N',num2str(gene_N_All(6)),'_c',c_num2str(c(6)),'_max_G',num2str(max_G)])
y{6} = c_All_Mean;
load (['c_All_Mean_Ring','_N',num2str(gene_N_All(7)),'_c',c_num2str(c(7)),'_max_G',num2str(max_G)])
y{7} = c_All_Mean;
load (['c_All_Mean_Ring','_N',num2str(gene_N_All(8)),'_c',c_num2str(c(8)),'_max_G',num2str(max_G)])
y{8} = c_All_Mean;
load (['c_All_Mean_Ring','_N',num2str(gene_N_All(9)),'_c',c_num2str(c(9)),'_max_G',num2str(max_G)])
y{9} = c_All_Mean;
%% plot results
for n=1:length(gene_N_All)  
    figure;
    plot(1:max_G/record_G,y{n}(1,:),'Color',[0.75 0 0.75],'LineWidth',1.5);
    hold on
    plot(1:max_G/record_G,y{n}(2,:),'Color',[0.5 0 0],'LineWidth',1.5);
    hold on;
    plot(1:max_G/record_G,y{n}(3,:),'Color',[0.5 0 0.5],'LineWidth',1.5);
    hold on;
    plot(1:max_G/record_G,y{n}(4,:),'Color',[0.168627455830574 0.505882382392883 0.337254911661148],'LineWidth',1.5);
    hold on;
    plot(1:max_G/record_G,y{n}(5,:),'Color',[0 0 1],'LineWidth',1.5);
    hold on;
    plot(1:max_G/record_G,y{n}(6,:),'Color',[1 0 0],'LineWidth',1.5);
    hold off;
    title({'Test for Network Connectivity Under Different Stability Selection Pressure' ,strcat(' [Pop=',num2str(size_Net),', N=',num2str(gene_N_All(n)),', c=',num2str(c(n)),', G=',num2str(max_G),']')},...
        'FontSize',30,...
        'FontName','Arial');
    xlabel(['Epochs (Generations/',num2str(record_G),')'],...
        'FontSize',25,...
        'FontName','Arial');
    ylabel(['Mean Network Connectivity',sprintf('\n')],...
        'FontSize',25,...
        'FontName','Arial');
    text1 = ['No Relaxed Selection'];
    text2 = ['Relaxed Selection Interval = ' num2str(num_Cycle_All(2))];
    text3 = ['Relaxed Selection Interval = ' num2str(num_Cycle_All(3))];
    text4 = ['Relaxed Selection Interval = ' num2str(num_Cycle_All(4))];
    text5 = ['Relaxed Selection Interval = ' num2str(num_Cycle_All(5))];
    text6 = ['Relaxed Selection Interval = ' num2str(num_Cycle_All(6))];
    legend1 = legend(text1,text2,text3,text4,text5,text6);
    set(legend1,'Location','NorthEast','FontSize',15,'FontName','Arial');
    set(gca,'FontSize',20)
    xlim([0 100])
end





%% Reshap Data (Star)
clear
close all
clc
%% set parameters
num_Cycle_All = [1 2 5 10 25 50];
gene_N_All = [10 10 20];
c = [0.17377 0.09 0.0475];
max_G = 5000;
for n=1:length(gene_N_All)
    %% load data
    load(generate_File_Name_Flipping_Star(gene_N_All(n),c(n),num_Cycle_All(1)))
    y1 = mean(c_Pop_All,2)';
    std1 = std(c_Pop_All,1,2)';
    load(generate_File_Name_Flipping_Star(gene_N_All(n),c(n),num_Cycle_All(2)))
    y2 = mean(c_Pop_All,2)';
    std2 = std(c_Pop_All,1,2)';
    load(generate_File_Name_Flipping_Star(gene_N_All(n),c(n),num_Cycle_All(3)))
    y3 = mean(c_Pop_All,2)';
    std3 = std(c_Pop_All,1,2)';
    load(generate_File_Name_Flipping_Star(gene_N_All(n),c(n),num_Cycle_All(4)))
    y4 = mean(c_Pop_All,2)';
    std4 = std(c_Pop_All,1,2)';
    load(generate_File_Name_Flipping_Star(gene_N_All(n),c(n),num_Cycle_All(5)))
    y5 = mean(c_Pop_All,2)';
    std5 = std(c_Pop_All,1,2)';
    load(generate_File_Name_Flipping_Star(gene_N_All(n),c(n),num_Cycle_All(6)))
    y6 = mean(c_Pop_All,2)';
    std6 = std(c_Pop_All,1,2)';
    %%
    c_All_Mean = [y1;y2;y3;y4;y5;y6];
    c_All_Std = [std1;std2;std3;std4;std5;std6];
    %% save results
    temp_Str = num2str(c(n));
    counter = 0;
    for m = 1:length(temp_Str)
        if (temp_Str(m)~='.')
            counter = counter+1;
            str_c(counter) = temp_Str(m);
        end
    end
    save_Name = ['c_All_Mean_Star','_N',num2str(gene_N_All(n)),'_c',str_c,'_max_G',num2str(max_G)];
    save (save_Name,'c_All_Mean') 
    save_Name = ['c_All_Std_Star','_N',num2str(gene_N_All(n)),'_c',str_c,'_max_G',num2str(max_G)];
    save (save_Name,'c_All_Std')
end


%% No Error Bar (Star)
clear
clc
num_Cycle_All = [1 2 5 10 25 50];
gene_N_All = [10 10 20];
c = [0.17377 0.09 0.0475];
max_G = 5000;
size_Net = 10000;
record_G = 50;
%% load data
load (['c_All_Mean_Star','_N',num2str(gene_N_All(1)),'_c',c_num2str(c(1)),'_max_G',num2str(max_G)])
y{1} = c_All_Mean;
load (['c_All_Mean_Star','_N',num2str(gene_N_All(2)),'_c',c_num2str(c(2)),'_max_G',num2str(max_G)])
y{2} = c_All_Mean;
load (['c_All_Mean_Star','_N',num2str(gene_N_All(3)),'_c',c_num2str(c(3)),'_max_G',num2str(max_G)])
y{3} = c_All_Mean;
load (['c_All_Mean_Star','_N',num2str(gene_N_All(4)),'_c',c_num2str(c(4)),'_max_G',num2str(max_G)])
y{4} = c_All_Mean;
load (['c_All_Mean_Star','_N',num2str(gene_N_All(5)),'_c',c_num2str(c(5)),'_max_G',num2str(max_G)])
y{5} = c_All_Mean;
load (['c_All_Mean_Star','_N',num2str(gene_N_All(6)),'_c',c_num2str(c(6)),'_max_G',num2str(max_G)])
y{6} = c_All_Mean;
load (['c_All_Mean_Star','_N',num2str(gene_N_All(7)),'_c',c_num2str(c(7)),'_max_G',num2str(max_G)])
y{7} = c_All_Mean;
load (['c_All_Mean_Star','_N',num2str(gene_N_All(8)),'_c',c_num2str(c(8)),'_max_G',num2str(max_G)])
y{8} = c_All_Mean;
load (['c_All_Mean_Star','_N',num2str(gene_N_All(9)),'_c',c_num2str(c(9)),'_max_G',num2str(max_G)])
y{9} = c_All_Mean;
%% plot results
for n=1:length(gene_N_All)  
    figure;
    plot(1:max_G/record_G,y{n}(1,:),'Color',[0.75 0 0.75],'LineWidth',1.5);
    hold on
    plot(1:max_G/record_G,y{n}(2,:),'Color',[0.5 0 0],'LineWidth',1.5);
    hold on;
    plot(1:max_G/record_G,y{n}(3,:),'Color',[0.5 0 0.5],'LineWidth',1.5);
    hold on;
    plot(1:max_G/record_G,y{n}(4,:),'Color',[0.168627455830574 0.505882382392883 0.337254911661148],'LineWidth',1.5);
    hold on;
    plot(1:max_G/record_G,y{n}(5,:),'Color',[0 0 1],'LineWidth',1.5);
    hold on;
    plot(1:max_G/record_G,y{n}(6,:),'Color',[1 0 0],'LineWidth',1.5);
    hold off;
    title({'Test for Network Connectivity Under Different Stability Selection Pressure' ,strcat(' [Pop=',num2str(size_Net),', N=',num2str(gene_N_All(n)),', c=',num2str(c(n)),', G=',num2str(max_G),']')},...
        'FontSize',30,...
        'FontName','Arial');
    xlabel(['Epochs (Generations/',num2str(record_G),')'],...
        'FontSize',25,...
        'FontName','Arial');
    ylabel(['Mean Network Connectivity',sprintf('\n')],...
        'FontSize',25,...
        'FontName','Arial');
    text1 = ['No Relaxed Selection'];
    text2 = ['Relaxed Selection Interval = ' num2str(num_Cycle_All(2))];
    text3 = ['Relaxed Selection Interval = ' num2str(num_Cycle_All(3))];
    text4 = ['Relaxed Selection Interval = ' num2str(num_Cycle_All(4))];
    text5 = ['Relaxed Selection Interval = ' num2str(num_Cycle_All(5))];
    text6 = ['Relaxed Selection Interval = ' num2str(num_Cycle_All(6))];
    legend1 = legend(text1,text2,text3,text4,text5,text6);
    set(legend1,'Location','NorthEast','FontSize',15,'FontName','Arial');
    set(gca,'FontSize',20)
    xlim([0 100])
end